/*
	This class builds state machines:
	it reads a human-readable .fsm file (Lua), checks it,
	and writes the binary file that cStateMachineDefinition loads
*/

#ifndef EAE6320_CSTATEMACHINEBUILDER_H
#define EAE6320_CSTATEMACHINEBUILDER_H

// Includes
//=========

#include <Tools/AssetBuildLibrary/iBuilder.h>

// Class Declaration
//==================

namespace eae6320
{
	namespace Assets
	{
		class cStateMachineBuilder final : public iBuilder
		{
			// Inherited Implementation
			//=========================

		private:

			// Build
			//------

			cResult Build( const std::vector<std::string>& i_arguments ) final;
		};
	}
}

#endif	// EAE6320_CSTATEMACHINEBUILDER_H
