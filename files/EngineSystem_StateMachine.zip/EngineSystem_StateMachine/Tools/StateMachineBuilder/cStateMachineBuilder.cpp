// Includes
//=========

#include "cStateMachineBuilder.h"

#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <limits>
#include <map>
#include <string>
#include <vector>
#include <Engine/ScopeGuard/cScopeGuard.h>
#include <Engine/StateMachine/BinaryFormat.h>
#include <External/Lua/Includes.h>
#include <Tools/AssetBuildLibrary/Functions.h>

// Helper Declarations
//====================

namespace
{
	namespace BinaryFormat = eae6320::AI::BinaryFormat;

	// Every count and index in the built file is a uint16_t,
	// and invalidIndex is reserved
	constexpr size_t s_maxCount = BinaryFormat::invalidIndex;

	// Everything that is known while a file is being read
	struct sBuildContext
	{
		const char* path = nullptr;
		// The source file's lines, used to find the line number for an error message
		// (Lua doesn't remember which line a table entry came from,
		// and so the line is found by searching the text for the name that the message is about)
		std::vector<std::string> sourceLines;
		// Searches for a line only move forward,
		// because the file is read in the same order that it was written
		unsigned int searchStartLine = 1;
		unsigned int errorCount = 0;

		// The data that will be written
		BinaryFormat::sHeader header{};
		std::vector<BinaryFormat::sParameter> parameters;
		std::vector<BinaryFormat::sState> states;
		std::vector<BinaryFormat::sTransition> transitions;
		std::vector<BinaryFormat::sCondition> conditions;
		std::string nameBlock;

		// Names to indices
		std::map<std::string, uint16_t> parameterIndices;
		std::map<std::string, uint16_t> stateIndices;
	};

	// Reading the human-readable file
	// (the comment at the start of each Load*() function says what is at the top of the Lua stack when it is called)
	eae6320::cResult LoadHumanReadableFile( sBuildContext& io_context );
	void LoadParameters( lua_State& io_luaState, sBuildContext& io_context );
	void LoadParameter( lua_State& io_luaState, sBuildContext& io_context, const lua_Integer i_index );
	void LoadStateNames( lua_State& io_luaState, sBuildContext& io_context );
	void LoadInitialState( lua_State& io_luaState, sBuildContext& io_context );
	void LoadAnyStateTransitions( lua_State& io_luaState, sBuildContext& io_context );
	void LoadStateTransitions( lua_State& io_luaState, sBuildContext& io_context );
	void LoadTransitions( lua_State& io_luaState, sBuildContext& io_context, const char* const i_owner );
	void LoadTransition( lua_State& io_luaState, sBuildContext& io_context, const char* const i_owner, const lua_Integer i_index );
	void LoadCondition( lua_State& io_luaState, sBuildContext& io_context, const char* const i_owner, const lua_Integer i_index,
		const char* const i_targetStateName );

	// Names
	uint16_t AddName( sBuildContext& io_context, const std::string& i_name );

	// Errors
	unsigned int FindLine( sBuildContext& io_context, const std::vector<std::string>& i_textsOnTheLine );
	void OutputError( sBuildContext& io_context, const unsigned int i_lineNumber, const char* const i_message, ... );
	void OutputLuaErrorMessage( const char* const i_path, const char* const i_luaErrorMessage );
	std::string Quote( const std::string& i_name );

	// Writing the binary file
	eae6320::cResult WriteBinaryFile( const char* const i_path, const char* const i_path_source, const sBuildContext& i_context );
}

// Inherited Implementation
//=========================

// Build
//------

eae6320::cResult eae6320::Assets::cStateMachineBuilder::Build( const std::vector<std::string>& )
{
	sBuildContext context;
	context.path = m_path_source;
	// The source text is only needed to find line numbers for error messages
	{
		std::ifstream sourceFile( m_path_source );
		std::string line;
		while ( std::getline( sourceFile, line ) )
		{
			context.sourceLines.push_back( line );
		}
	}

	if ( const auto result = LoadHumanReadableFile( context ); !result )
	{
		return result;
	}
	// Every problem in the file is reported (instead of only the first one),
	// so that they can all be fixed at once
	if ( context.errorCount > 0 )
	{
		return eae6320::Results::InvalidFile;
	}

	return WriteBinaryFile( m_path_target, m_path_source, context );
}

// Helper Definitions
//===================

namespace
{
	// Reading
	//--------

	eae6320::cResult LoadHumanReadableFile( sBuildContext& io_context )
	{
		const char* const path = io_context.path;

		// Create a new Lua state
		lua_State* luaState = nullptr;
		eae6320::cScopeGuard scopeGuard_onExit( [&luaState]
			{
				if ( luaState )
				{
					lua_close( luaState );
					luaState = nullptr;
				}
			} );
		{
			luaState = luaL_newstate();
			if ( !luaState )
			{
				eae6320::Assets::OutputErrorMessageWithFileInfo( path, "Failed to create a new Lua state to read the state machine" );
				return eae6320::Results::OutOfMemory;
			}
		}

		// Load the file as a "chunk" (a function)
		{
			const auto luaResult = luaL_loadfile( luaState, path );
			if ( luaResult != LUA_OK )
			{
				OutputLuaErrorMessage( path, lua_tostring( luaState, -1 ) );
				lua_pop( luaState, 1 );
				return ( luaResult == LUA_ERRFILE ) ? eae6320::Results::FileDoesntExist : eae6320::Results::InvalidFile;
			}
		}
		// Run the chunk; a state machine file must return exactly one table
		{
			constexpr int argumentCount = 0;
			constexpr int returnValueCount = 1;
			constexpr int noMessageHandler = 0;
			const auto luaResult = lua_pcall( luaState, argumentCount, returnValueCount, noMessageHandler );
			if ( luaResult != LUA_OK )
			{
				OutputLuaErrorMessage( path, lua_tostring( luaState, -1 ) );
				lua_pop( luaState, 1 );
				return eae6320::Results::InvalidFile;
			}
		}
		// Stack: the value that the file returned
		eae6320::cScopeGuard scopeGuard_popAssetTable( [luaState]
			{
				lua_pop( luaState, 1 );
			} );
		if ( !lua_istable( luaState, -1 ) )
		{
			eae6320::Assets::OutputErrorMessageWithFileInfo( path,
				"The state machine file must return a table (instead of a %s)", luaL_typename( luaState, -1 ) );
			return eae6320::Results::InvalidFile;
		}

		// The parameters and the state names are read first
		// so that every name that a transition uses can be turned into an index
		// (a transition can go to a state that is written further down in the file)
		LoadParameters( *luaState, io_context );
		LoadStateNames( *luaState, io_context );
		LoadInitialState( *luaState, io_context );
		// The "any state" transitions are stored first in the transition array
		LoadAnyStateTransitions( *luaState, io_context );
		LoadStateTransitions( *luaState, io_context );

		return eae6320::Results::Success;
	}

	void LoadParameters( lua_State& io_luaState, sBuildContext& io_context )
	{
		// Stack: the asset table
		lua_getfield( &io_luaState, -1, "parameters" );
		// Stack: parameters (or nil), the asset table
		eae6320::cScopeGuard scopeGuard_popParameters( [&io_luaState]
			{
				lua_pop( &io_luaState, 1 );
			} );
		// A state machine doesn't have to have any parameters
		// (its transitions could all depend on time alone)
		if ( lua_isnil( &io_luaState, -1 ) )
		{
			return;
		}
		if ( !lua_istable( &io_luaState, -1 ) )
		{
			OutputError( io_context, FindLine( io_context, { "parameters" } ),
				"\"parameters\" must be a table (instead of a %s)", luaL_typename( &io_luaState, -1 ) );
			return;
		}

		const auto parameterCount = luaL_len( &io_luaState, -1 );
		if ( static_cast<lua_Unsigned>( parameterCount ) > s_maxCount )
		{
			OutputError( io_context, 0, "A state machine can't have more than %zu parameters", s_maxCount );
			return;
		}
		for ( lua_Integer i = 1; i <= parameterCount; ++i )
		{
			lua_rawgeti( &io_luaState, -1, i );
			// Stack: parameter i, parameters, the asset table
			LoadParameter( io_luaState, io_context, i );
			lua_pop( &io_luaState, 1 );
		}
	}

	void LoadParameter( lua_State& io_luaState, sBuildContext& io_context, const lua_Integer i_index )
	{
		// Stack: a parameter
		if ( !lua_istable( &io_luaState, -1 ) )
		{
			OutputError( io_context, 0, "Parameter #%lld must be a table (instead of a %s)",
				static_cast<long long>( i_index ), luaL_typename( &io_luaState, -1 ) );
			return;
		}

		// Name
		std::string name;
		unsigned int lineNumber = 0;
		{
			lua_getfield( &io_luaState, -1, "name" );
			if ( lua_type( &io_luaState, -1 ) == LUA_TSTRING )
			{
				name = lua_tostring( &io_luaState, -1 );
			}
			lua_pop( &io_luaState, 1 );
			if ( name.empty() )
			{
				OutputError( io_context, 0, "Parameter #%lld must have a \"name\" string", static_cast<long long>( i_index ) );
				return;
			}
			lineNumber = FindLine( io_context, { "name", Quote( name ) } );
			// The next parameter is further down
			// (so that a duplicate name is reported on the line of the duplicate)
			if ( lineNumber > 0 )
			{
				io_context.searchStartLine = lineNumber + 1;
			}
			if ( io_context.parameterIndices.find( name ) != io_context.parameterIndices.end() )
			{
				OutputError( io_context, lineNumber, "There is more than one parameter named \"%s\"", name.c_str() );
				return;
			}
		}

		BinaryFormat::sParameter parameter{};
		// Type
		{
			lua_getfield( &io_luaState, -1, "type" );
			const std::string type = ( lua_type( &io_luaState, -1 ) == LUA_TSTRING ) ? lua_tostring( &io_luaState, -1 ) : "";
			lua_pop( &io_luaState, 1 );
			if ( type == "float" )
			{
				parameter.type = eae6320::AI::eParameterType::Float;
			}
			else if ( type == "bool" )
			{
				parameter.type = eae6320::AI::eParameterType::Bool;
			}
			else if ( type == "trigger" )
			{
				parameter.type = eae6320::AI::eParameterType::Trigger;
			}
			else
			{
				OutputError( io_context, lineNumber, "The parameter \"%s\" must have a \"type\" of \"float\", \"bool\", or \"trigger\"",
					name.c_str() );
				return;
			}
		}
		// Default value
		{
			lua_getfield( &io_luaState, -1, "default" );
			// Stack: default (or nil), the parameter
			// A missing default is 0 or false
			if ( !lua_isnil( &io_luaState, -1 ) )
			{
				switch ( parameter.type )
				{
				case eae6320::AI::eParameterType::Float:
					if ( lua_type( &io_luaState, -1 ) == LUA_TNUMBER )
					{
						parameter.defaultValue = static_cast<float>( lua_tonumber( &io_luaState, -1 ) );
					}
					else
					{
						OutputError( io_context, lineNumber, "The default value of the float parameter \"%s\" must be a number (instead of a %s)",
							name.c_str(), luaL_typename( &io_luaState, -1 ) );
					}
					break;
				case eae6320::AI::eParameterType::Bool:
					if ( lua_isboolean( &io_luaState, -1 ) )
					{
						parameter.defaultValue = lua_toboolean( &io_luaState, -1 ) ? 1.0f : 0.0f;
					}
					else
					{
						OutputError( io_context, lineNumber, "The default value of the bool parameter \"%s\" must be true or false (instead of a %s)",
							name.c_str(), luaL_typename( &io_luaState, -1 ) );
					}
					break;
				case eae6320::AI::eParameterType::Trigger:
					// A trigger always starts unset
					OutputError( io_context, lineNumber, "The trigger \"%s\" can't have a default value (triggers always start unset)",
						name.c_str() );
					break;
				}
			}
			lua_pop( &io_luaState, 1 );
		}

		if ( io_context.parameters.size() >= s_maxCount )
		{
			return;
		}
		parameter.nameOffset = AddName( io_context, name );
		io_context.parameterIndices[name] = static_cast<uint16_t>( io_context.parameters.size() );
		io_context.parameters.push_back( parameter );
	}

	void LoadStateNames( lua_State& io_luaState, sBuildContext& io_context )
	{
		// Stack: the asset table
		lua_getfield( &io_luaState, -1, "states" );
		// Stack: states, the asset table
		eae6320::cScopeGuard scopeGuard_popStates( [&io_luaState]
			{
				lua_pop( &io_luaState, 1 );
			} );
		if ( !lua_istable( &io_luaState, -1 ) || ( luaL_len( &io_luaState, -1 ) < 1 ) )
		{
			OutputError( io_context, FindLine( io_context, { "states" } ),
				"The state machine file must have a \"states\" array with at least one state" );
			return;
		}

		const auto stateCount = luaL_len( &io_luaState, -1 );
		if ( static_cast<lua_Unsigned>( stateCount ) > s_maxCount )
		{
			OutputError( io_context, 0, "A state machine can't have more than %zu states", s_maxCount );
			return;
		}
		// Only the names are read now;
		// the transitions are read after every state has an index
		const auto searchStartLine = io_context.searchStartLine;
		for ( lua_Integer i = 1; i <= stateCount; ++i )
		{
			lua_rawgeti( &io_luaState, -1, i );
			// Stack: state i, states, the asset table
			std::string name;
			if ( lua_istable( &io_luaState, -1 ) )
			{
				lua_getfield( &io_luaState, -1, "name" );
				if ( lua_type( &io_luaState, -1 ) == LUA_TSTRING )
				{
					name = lua_tostring( &io_luaState, -1 );
				}
				lua_pop( &io_luaState, 1 );
			}
			lua_pop( &io_luaState, 1 );

			// Every state gets an entry (even an invalid one) so that the indices match the order in the file
			BinaryFormat::sState state{};
			if ( name.empty() )
			{
				OutputError( io_context, 0, "State #%lld must be a table with a \"name\" string", static_cast<long long>( i ) );
			}
			else
			{
				const auto lineNumber = FindLine( io_context, { "name", Quote( name ) } );
				if ( lineNumber > 0 )
				{
					io_context.searchStartLine = lineNumber + 1;
				}
				if ( io_context.stateIndices.find( name ) != io_context.stateIndices.end() )
				{
					OutputError( io_context, lineNumber, "There is more than one state named \"%s\"", name.c_str() );
				}
				else
				{
					io_context.stateIndices[name] = static_cast<uint16_t>( io_context.states.size() );
				}
				state.nameOffset = AddName( io_context, name );
			}
			io_context.states.push_back( state );
		}
		// The states will be read again for their transitions
		io_context.searchStartLine = searchStartLine;
	}

	void LoadInitialState( lua_State& io_luaState, sBuildContext& io_context )
	{
		// Stack: the asset table
		lua_getfield( &io_luaState, -1, "initialState" );
		const std::string name = ( lua_type( &io_luaState, -1 ) == LUA_TSTRING ) ? lua_tostring( &io_luaState, -1 ) : "";
		lua_pop( &io_luaState, 1 );

		io_context.header.initialState = BinaryFormat::invalidIndex;
		if ( name.empty() )
		{
			OutputError( io_context, 0, "The state machine file must have an \"initialState\" string with the name of a state" );
			return;
		}
		const auto iterator = io_context.stateIndices.find( name );
		if ( iterator == io_context.stateIndices.end() )
		{
			// The initial state is usually at the top, before the parameters,
			// and so the search for its line starts at the beginning of the file
			const auto searchStartLine = io_context.searchStartLine;
			io_context.searchStartLine = 1;
			const auto lineNumber = FindLine( io_context, { "initialState" } );
			io_context.searchStartLine = searchStartLine;
			OutputError( io_context, lineNumber, "The initial state \"%s\" doesn't exist", name.c_str() );
			return;
		}
		io_context.header.initialState = iterator->second;
	}

	void LoadAnyStateTransitions( lua_State& io_luaState, sBuildContext& io_context )
	{
		// Stack: the asset table
		lua_getfield( &io_luaState, -1, "anyState" );
		// Stack: anyState (or nil), the asset table
		eae6320::cScopeGuard scopeGuard_popAnyState( [&io_luaState]
			{
				lua_pop( &io_luaState, 1 );
			} );
		if ( !lua_isnil( &io_luaState, -1 ) )
		{
			const auto lineNumber = FindLine( io_context, { "anyState" } );
			if ( lineNumber > 0 )
			{
				io_context.searchStartLine = lineNumber;
			}
			LoadTransitions( io_luaState, io_context, "\"any state\"" );
		}
		io_context.header.anyStateTransitionCount = static_cast<uint16_t>( io_context.transitions.size() );
	}

	void LoadStateTransitions( lua_State& io_luaState, sBuildContext& io_context )
	{
		// Stack: the asset table
		lua_getfield( &io_luaState, -1, "states" );
		// Stack: states, the asset table
		eae6320::cScopeGuard scopeGuard_popStates( [&io_luaState]
			{
				lua_pop( &io_luaState, 1 );
			} );
		if ( !lua_istable( &io_luaState, -1 ) )
		{
			// This has already been reported
			return;
		}
		{
			const auto lineNumber = FindLine( io_context, { "states" } );
			if ( lineNumber > 0 )
			{
				io_context.searchStartLine = lineNumber;
			}
		}

		const auto stateCount = static_cast<lua_Integer>( io_context.states.size() );
		for ( lua_Integer i = 1; i <= stateCount; ++i )
		{
			lua_rawgeti( &io_luaState, -1, i );
			// Stack: state i, states, the asset table
			eae6320::cScopeGuard scopeGuard_popState( [&io_luaState]
				{
					lua_pop( &io_luaState, 1 );
				} );
			if ( !lua_istable( &io_luaState, -1 ) )
			{
				continue;
			}
			auto& state = io_context.states[static_cast<size_t>( i - 1 )];
			const std::string name = io_context.nameBlock.c_str() + state.nameOffset;
			{
				const auto lineNumber = FindLine( io_context, { "name", Quote( name ) } );
				if ( lineNumber > 0 )
				{
					io_context.searchStartLine = lineNumber;
				}
			}

			state.firstTransition = static_cast<uint16_t>( io_context.transitions.size() );
			lua_getfield( &io_luaState, -1, "transitions" );
			// Stack: transitions (or nil), state i, states, the asset table
			// A state doesn't need transitions (e.g. a final "Dead" state, or one that only "any state" transitions leave)
			if ( !lua_isnil( &io_luaState, -1 ) )
			{
				const std::string owner = "state \"" + name + "\"";
				LoadTransitions( io_luaState, io_context, owner.c_str() );
			}
			lua_pop( &io_luaState, 1 );
			state.transitionCount = static_cast<uint16_t>( io_context.transitions.size() - state.firstTransition );
		}
	}

	void LoadTransitions( lua_State& io_luaState, sBuildContext& io_context, const char* const i_owner )
	{
		// Stack: a transition array
		if ( !lua_istable( &io_luaState, -1 ) )
		{
			OutputError( io_context, 0, "The transitions of %s must be a table (instead of a %s)", i_owner, luaL_typename( &io_luaState, -1 ) );
			return;
		}
		const auto transitionCount = luaL_len( &io_luaState, -1 );
		for ( lua_Integer i = 1; i <= transitionCount; ++i )
		{
			lua_rawgeti( &io_luaState, -1, i );
			// Stack: transition i, the transition array
			LoadTransition( io_luaState, io_context, i_owner, i );
			lua_pop( &io_luaState, 1 );
		}
	}

	void LoadTransition( lua_State& io_luaState, sBuildContext& io_context, const char* const i_owner, const lua_Integer i_index )
	{
		// Stack: a transition
		if ( !lua_istable( &io_luaState, -1 ) )
		{
			OutputError( io_context, 0, "Transition #%lld of %s must be a table (instead of a %s)",
				static_cast<long long>( i_index ), i_owner, luaL_typename( &io_luaState, -1 ) );
			return;
		}

		BinaryFormat::sTransition transition{};
		transition.targetState = BinaryFormat::invalidIndex;

		// Target state
		std::string targetName;
		{
			lua_getfield( &io_luaState, -1, "to" );
			if ( lua_type( &io_luaState, -1 ) == LUA_TSTRING )
			{
				targetName = lua_tostring( &io_luaState, -1 );
			}
			lua_pop( &io_luaState, 1 );
			if ( targetName.empty() )
			{
				OutputError( io_context, 0, "Transition #%lld of %s must have a \"to\" string with the name of the target state",
					static_cast<long long>( i_index ), i_owner );
				return;
			}
			const auto lineNumber = FindLine( io_context, { "to", Quote( targetName ) } );
			if ( lineNumber > 0 )
			{
				io_context.searchStartLine = lineNumber;
			}
			const auto iterator = io_context.stateIndices.find( targetName );
			if ( iterator != io_context.stateIndices.end() )
			{
				transition.targetState = iterator->second;
			}
			else
			{
				OutputError( io_context, lineNumber, "Transition #%lld of %s goes to the state \"%s\", which doesn't exist",
					static_cast<long long>( i_index ), i_owner, targetName.c_str() );
			}
		}
		// Minimum time in state
		{
			lua_getfield( &io_luaState, -1, "minimumTimeInState" );
			if ( !lua_isnil( &io_luaState, -1 ) )
			{
				if ( ( lua_type( &io_luaState, -1 ) == LUA_TNUMBER ) && ( lua_tonumber( &io_luaState, -1 ) >= 0.0 ) )
				{
					transition.minimumTimeInState = static_cast<float>( lua_tonumber( &io_luaState, -1 ) );
				}
				else
				{
					OutputError( io_context, FindLine( io_context, { "minimumTimeInState" } ),
						"The \"minimumTimeInState\" of transition #%lld of %s must be a number of seconds that isn't negative",
						static_cast<long long>( i_index ), i_owner );
				}
			}
			lua_pop( &io_luaState, 1 );
		}
		// Conditions
		transition.firstCondition = static_cast<uint16_t>( io_context.conditions.size() );
		{
			lua_getfield( &io_luaState, -1, "conditions" );
			// Stack: conditions (or nil), the transition
			// A transition without conditions fires as soon as its minimum time has passed
			if ( !lua_isnil( &io_luaState, -1 ) )
			{
				if ( lua_istable( &io_luaState, -1 ) )
				{
					const auto conditionCount = luaL_len( &io_luaState, -1 );
					for ( lua_Integer i = 1; i <= conditionCount; ++i )
					{
						lua_rawgeti( &io_luaState, -1, i );
						// Stack: condition i, conditions, the transition
						LoadCondition( io_luaState, io_context, i_owner, i_index, targetName.c_str() );
						lua_pop( &io_luaState, 1 );
					}
				}
				else
				{
					OutputError( io_context, 0, "The \"conditions\" of transition #%lld of %s must be a table (instead of a %s)",
						static_cast<long long>( i_index ), i_owner, luaL_typename( &io_luaState, -1 ) );
				}
			}
			lua_pop( &io_luaState, 1 );
		}
		transition.conditionCount = static_cast<uint16_t>( io_context.conditions.size() - transition.firstCondition );

		if ( io_context.transitions.size() >= s_maxCount )
		{
			OutputError( io_context, 0, "A state machine can't have more than %zu transitions", s_maxCount );
			return;
		}
		io_context.transitions.push_back( transition );
	}

	void LoadCondition( lua_State& io_luaState, sBuildContext& io_context, const char* const i_owner, const lua_Integer i_index,
		const char* const i_targetStateName )
	{
		// Stack: a condition
		// A condition is written as { parameterName, comparison, value },
		// or as { parameterName } for a trigger (or for a bool that must be true)
		const auto elementCount = lua_istable( &io_luaState, -1 ) ? luaL_len( &io_luaState, -1 ) : 0;
		std::string parameterName;
		if ( elementCount >= 1 )
		{
			lua_rawgeti( &io_luaState, -1, 1 );
			if ( lua_type( &io_luaState, -1 ) == LUA_TSTRING )
			{
				parameterName = lua_tostring( &io_luaState, -1 );
			}
			lua_pop( &io_luaState, 1 );
		}
		if ( parameterName.empty() || ( ( elementCount != 1 ) && ( elementCount != 3 ) ) )
		{
			OutputError( io_context, 0,
				"A condition of transition #%lld of %s (to \"%s\") must be { parameterName, comparison, value } or { triggerName }",
				static_cast<long long>( i_index ), i_owner, i_targetStateName );
			return;
		}
		const auto lineNumber = FindLine( io_context, { Quote( parameterName ) } );

		const auto parameterIterator = io_context.parameterIndices.find( parameterName );
		if ( parameterIterator == io_context.parameterIndices.end() )
		{
			OutputError( io_context, lineNumber, "A condition of transition #%lld of %s (to \"%s\") uses the parameter \"%s\", which doesn't exist",
				static_cast<long long>( i_index ), i_owner, i_targetStateName, parameterName.c_str() );
			return;
		}
		BinaryFormat::sCondition condition{};
		condition.parameter = parameterIterator->second;
		const auto parameterType = io_context.parameters[condition.parameter].type;

		if ( elementCount == 1 )
		{
			// The short form only makes sense for a value that is true or false
			if ( parameterType == eae6320::AI::eParameterType::Trigger )
			{
				condition.comparison = eae6320::AI::eComparison::IsSet;
			}
			else if ( parameterType == eae6320::AI::eParameterType::Bool )
			{
				condition.comparison = eae6320::AI::eComparison::Equal;
				condition.value = 1.0f;
			}
			else
			{
				OutputError( io_context, lineNumber, "The float parameter \"%s\" must be compared with a value (e.g. { \"%s\", \"<\", 2.0 })",
					parameterName.c_str(), parameterName.c_str() );
				return;
			}
		}
		else
		{
			if ( parameterType == eae6320::AI::eParameterType::Trigger )
			{
				OutputError( io_context, lineNumber, "The trigger \"%s\" can't be compared with a value; write it as { \"%s\" }",
					parameterName.c_str(), parameterName.c_str() );
				return;
			}
			// Comparison
			std::string comparisonText;
			{
				lua_rawgeti( &io_luaState, -1, 2 );
				if ( lua_type( &io_luaState, -1 ) == LUA_TSTRING )
				{
					comparisonText = lua_tostring( &io_luaState, -1 );
				}
				lua_pop( &io_luaState, 1 );
			}
			// The comparisons use Lua's spelling (and so "not equal" is ~=)
			struct sComparisonName { const char* text; eae6320::AI::eComparison comparison; bool isOrdered; };
			constexpr sComparisonName comparisonNames[] =
			{
				{ "<", eae6320::AI::eComparison::Less, true },
				{ "<=", eae6320::AI::eComparison::LessOrEqual, true },
				{ ">", eae6320::AI::eComparison::Greater, true },
				{ ">=", eae6320::AI::eComparison::GreaterOrEqual, true },
				{ "==", eae6320::AI::eComparison::Equal, false },
				{ "~=", eae6320::AI::eComparison::NotEqual, false },
			};
			const sComparisonName* foundComparison = nullptr;
			for ( const auto& comparisonName : comparisonNames )
			{
				if ( comparisonText == comparisonName.text )
				{
					foundComparison = &comparisonName;
					break;
				}
			}
			if ( !foundComparison )
			{
				OutputError( io_context, lineNumber, "\"%s\" isn't a comparison (use <, <=, >, >=, ==, or ~=)", comparisonText.c_str() );
				return;
			}
			if ( ( parameterType == eae6320::AI::eParameterType::Bool ) && foundComparison->isOrdered )
			{
				OutputError( io_context, lineNumber, "The bool parameter \"%s\" can't be compared with %s (only == and ~= can be used with a bool)",
					parameterName.c_str(), comparisonText.c_str() );
				return;
			}
			condition.comparison = foundComparison->comparison;
			// Value
			lua_rawgeti( &io_luaState, -1, 3 );
			// Stack: the value, the condition
			if ( parameterType == eae6320::AI::eParameterType::Float )
			{
				if ( lua_type( &io_luaState, -1 ) == LUA_TNUMBER )
				{
					condition.value = static_cast<float>( lua_tonumber( &io_luaState, -1 ) );
				}
				else
				{
					OutputError( io_context, lineNumber, "The float parameter \"%s\" must be compared with a number (instead of a %s)",
						parameterName.c_str(), luaL_typename( &io_luaState, -1 ) );
				}
			}
			else
			{
				if ( lua_isboolean( &io_luaState, -1 ) )
				{
					condition.value = lua_toboolean( &io_luaState, -1 ) ? 1.0f : 0.0f;
				}
				else
				{
					OutputError( io_context, lineNumber, "The bool parameter \"%s\" must be compared with true or false (instead of a %s)",
						parameterName.c_str(), luaL_typename( &io_luaState, -1 ) );
				}
			}
			lua_pop( &io_luaState, 1 );
		}

		if ( io_context.conditions.size() >= s_maxCount )
		{
			OutputError( io_context, 0, "A state machine can't have more than %zu conditions", s_maxCount );
			return;
		}
		io_context.conditions.push_back( condition );
	}

	// Names
	//------

	uint16_t AddName( sBuildContext& io_context, const std::string& i_name )
	{
		// Every name is stored once, null-terminated, at the end of the block
		const auto offset = io_context.nameBlock.size();
		io_context.nameBlock.append( i_name );
		io_context.nameBlock.push_back( '\0' );
		// The offsets are stored as uint16_ts
		// (WriteBinaryFile() reports a block that is too big)
		return static_cast<uint16_t>( offset );
	}

	// Errors
	//-------

	unsigned int FindLine( sBuildContext& io_context, const std::vector<std::string>& i_textsOnTheLine )
	{
		// Returns the first line (starting at the search start) that contains every given text,
		// or 0 if there is none (and then the error is shown without a line number)
		for ( auto lineNumber = io_context.searchStartLine; lineNumber <= io_context.sourceLines.size(); ++lineNumber )
		{
			const auto& line = io_context.sourceLines[lineNumber - 1];
			// Lines that are only a comment are skipped
			const auto firstCharacter = line.find_first_not_of( " \t" );
			if ( ( firstCharacter != std::string::npos ) && ( line.compare( firstCharacter, 2, "--" ) == 0 ) )
			{
				continue;
			}
			bool areAllTextsFound = true;
			for ( const auto& text : i_textsOnTheLine )
			{
				if ( line.find( text ) == std::string::npos )
				{
					areAllTextsFound = false;
					break;
				}
			}
			if ( areAllTextsFound )
			{
				return lineNumber;
			}
		}
		return 0;
	}

	void OutputError( sBuildContext& io_context, const unsigned int i_lineNumber, const char* const i_message, ... )
	{
		++io_context.errorCount;

		char message[1024];
		{
			va_list insertions;
			va_start( insertions, i_message );
			vsnprintf( message, sizeof( message ), i_message, insertions );
			va_end( insertions );
		}
		// With a line number Visual Studio can jump straight to the problem when the error is double-clicked
		if ( i_lineNumber > 0 )
		{
			eae6320::Assets::OutputErrorMessageWithFileInfo( io_context.path, i_lineNumber, "%s", message );
		}
		else
		{
			eae6320::Assets::OutputErrorMessageWithFileInfo( io_context.path, "%s", message );
		}
	}

	void OutputLuaErrorMessage( const char* const i_path, const char* const i_luaErrorMessage )
	{
		// The engine's Lua library formats its error messages like "<path>(<line>) : error: <message>".
		// If the line number can be found it is passed on so that Visual Studio can jump to the line
		// (the path in the message may be shortened by Lua, and so the real path is used instead).
		const std::string luaErrorMessage = i_luaErrorMessage ? i_luaErrorMessage : "Unknown Lua error";
		constexpr const char* const lineNumberEndMarker = ") : error: ";
		const auto lineNumberEnd = luaErrorMessage.find( lineNumberEndMarker );
		if ( ( lineNumberEnd != std::string::npos ) && ( lineNumberEnd > 0 ) )
		{
			const auto lineNumberStart = luaErrorMessage.rfind( '(', lineNumberEnd - 1 ) + 1;
			const auto lineNumberText = luaErrorMessage.substr( lineNumberStart, lineNumberEnd - lineNumberStart );
			if ( ( lineNumberStart > 0 ) && !lineNumberText.empty()
				&& ( lineNumberText.find_first_not_of( "0123456789" ) == std::string::npos ) )
			{
				const auto lineNumber = static_cast<unsigned int>( std::strtoul( lineNumberText.c_str(), nullptr, 10 ) );
				eae6320::Assets::OutputErrorMessageWithFileInfo( i_path, lineNumber, "%s",
					luaErrorMessage.c_str() + lineNumberEnd + std::strlen( lineNumberEndMarker ) );
				return;
			}
		}
		eae6320::Assets::OutputErrorMessageWithFileInfo( i_path, "%s", luaErrorMessage.c_str() );
	}

	std::string Quote( const std::string& i_name )
	{
		return "\"" + i_name + "\"";
	}

	// Writing
	//--------

	eae6320::cResult WriteBinaryFile( const char* const i_path, const char* const i_path_source, const sBuildContext& i_context )
	{
		// Name offsets are stored as uint16_ts
		if ( i_context.nameBlock.size() > std::numeric_limits<uint16_t>::max() )
		{
			eae6320::Assets::OutputErrorMessageWithFileInfo( i_path_source, "The names in the state machine are too long (%zu bytes in total)",
				i_context.nameBlock.size() );
			return eae6320::Results::InvalidFile;
		}

		auto header = i_context.header;
		header.fileVersion = BinaryFormat::currentFileVersion;
		header.parameterCount = static_cast<uint16_t>( i_context.parameters.size() );
		header.stateCount = static_cast<uint16_t>( i_context.states.size() );
		header.transitionCount = static_cast<uint16_t>( i_context.transitions.size() );
		header.conditionCount = static_cast<uint16_t>( i_context.conditions.size() );
		header.nameBlockSize = static_cast<uint16_t>( i_context.nameBlock.size() );

		std::ofstream outputFile( i_path, std::ofstream::binary );
		if ( !outputFile.is_open() )
		{
			eae6320::Assets::OutputErrorMessageWithFileInfo( i_path_source, "The built state machine file \"%s\" couldn't be opened for writing", i_path );
			return eae6320::Results::Failure;
		}

		// The order must match what cStateMachineDefinition::Initialize() expects:
		// the header, then each array, then the names
		// (see BinaryFormat.h)
		const auto writeArray = [&outputFile]( const auto& i_array )
		{
			if ( !i_array.empty() )
			{
				outputFile.write( reinterpret_cast<const char*>( i_array.data() ),
					static_cast<std::streamsize>( sizeof( i_array[0] ) * i_array.size() ) );
			}
		};
		outputFile.write( reinterpret_cast<const char*>( &header ), sizeof( header ) );
		writeArray( i_context.parameters );
		writeArray( i_context.states );
		writeArray( i_context.transitions );
		writeArray( i_context.conditions );
		outputFile.write( i_context.nameBlock.data(), static_cast<std::streamsize>( i_context.nameBlock.size() ) );

		outputFile.close();
		if ( outputFile.fail() )
		{
			eae6320::Assets::OutputErrorMessageWithFileInfo( i_path_source, "The built state machine file \"%s\" couldn't be written", i_path );
			return eae6320::Results::Failure;
		}

		return eae6320::Results::Success;
	}
}
