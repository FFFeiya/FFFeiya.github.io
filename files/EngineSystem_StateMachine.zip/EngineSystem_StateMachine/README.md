# State Machine engine system

A small finite state machine system for the EAE6320 engine. You describe an AI (a guard, a door, a turret, an enemy wave...) in a human-readable `.fsm` file, the asset build turns it into a compact binary file, and your game loads it and runs one small state machine per agent. Your game code sets a few parameters every update ("distance to the player", "was hit") and reacts to state changes in callbacks. The rules for when to change state live in the `.fsm` file, so you can tune them without touching C++.

Author: Feiyang Yang. If something in here doesn't work for you, ask me in class and I'll fix the instructions.

## Contents

1. [What is in the ZIP](#what-is-in-the-zip)
2. [Installation](#installation)
3. [The .fsm file format](#the-fsm-file-format)
4. [Using it in your game](#using-it-in-your-game)
5. [Debug output](#debug-output)
6. [Known limits](#known-limits)
7. [Troubleshooting](#troubleshooting)

## What is in the ZIP

Everything is inside one `EngineSystem_StateMachine` folder:

```text
Engine/StateMachine/              the run-time static library (project "StateMachine")
    cStateMachineDefinition.h/.cpp    the shared, read-only part loaded from a built file (reference counted)
    cStateMachine.h/.cpp              the per-agent part: current state, parameter values, callbacks
    BinaryFormat.h                    the layout of the built file (shared with the builder)
    DebugOutput.h/.cpp                writes a line for every state change; you can replace the output function
    Configuration.h                   turns the debug output on/off (on in Debug builds)
    Windows/DebugOutput.win.cpp       the only platform-specific code (OutputDebugStringA)
    Windows/ExternalLibraries.win.h
    StateMachine.vcxproj(.filters)
Tools/StateMachineBuilder/        the builder (project "StateMachineBuilder", makes StateMachineBuilder.exe)
    cStateMachineBuilder.h/.cpp       reads and validates a .fsm file and writes the binary .fsmbin file
    EntryPoint.cpp
    StateMachineBuilder.vcxproj(.filters)
Examples/
    guard.fsm                         patrol / chase / attack / flee, floats, bools, a trigger, anyState
    door.fsm                          closed / opening / open / closing / locked, a bool, a trigger, timed transitions
README.md                         this file
```

Nothing else is needed. The library only uses engine projects that everybody has (Asserts, Logging, Platform, Results, Windows), and the builder only uses Asserts, Platform, Windows, Lua and AssetBuildLibrary.

## Installation

These steps assume your solution has the usual layout (`Engine\`, `Tools\`, `MyGame_\` next to the `.sln`). They take about 10 minutes.

### 1. Copy the folders

Copy `Engine\StateMachine` into your `Engine` folder and `Tools\StateMachineBuilder` into your `Tools` folder, so that you have:

```text
<your solution folder>\Engine\StateMachine\StateMachine.vcxproj
<your solution folder>\Tools\StateMachineBuilder\StateMachineBuilder.vcxproj
```

The project files use relative paths like `..\..\Engine\Platform\Platform.vcxproj`, so the folders have to be exactly there.

### 2. Add the two projects to the solution

In Visual Studio, right-click the **Engine** solution folder > Add > Existing Project... and choose `Engine\StateMachine\StateMachine.vcxproj`.
Then right-click the **Tools** solution folder > Add > Existing Project... and choose `Tools\StateMachineBuilder\StateMachineBuilder.vcxproj`.

(The solution folders are only for tidiness; if yours are named differently, use those.)

Both projects already have all four configurations (Debug/Release x x64/x86) and import the engine's `EngineDefaults.props` and `Direct3D.props`/`OpenGL.props` like the other engine projects.

### 3. Set up the dependencies

Two things must depend on the new projects:

1. **Your game links the library.** Right-click your game project (e.g. **MyGame**) > Add > Reference... > check **StateMachine** > OK.
2. **The asset build needs the builder.** Right-click your asset build project (e.g. **BuildMyGameAssets**) > Build Dependencies > Project Dependencies... > check **StateMachineBuilder** > OK.
   This is the same thing that you did for MeshBuilder: it makes sure `StateMachineBuilder.exe` exists before your assets are built.

You don't need to change the include directories: the engine's props already let you write `#include <Engine/StateMachine/cStateMachine.h>`.

### 4. Tell the asset build system about the new asset type

Open `Tools\AssetBuildLibrary\AssetBuildFunctions.lua`, find where the other asset types are registered (the `NewAssetTypeInfo( "meshes", ... )` block), and add this after it:

```lua
-- State Machines
--===============

NewAssetTypeInfo( "stateMachines",
	{
		ConvertSourceRelativePathToBuiltRelativePath = function( i_sourceRelativePath )
			-- Built state machines are binary, and so they get a different extension
			-- than the human-readable source files
			local relativeDirectory, file = i_sourceRelativePath:match( "(.-)([^/\\]+)$" )
			local fileName = file:match( "([^%.]+)" )
			return relativeDirectory .. fileName .. ".fsmbin"
		end,
		GetBuilderRelativePath = function()
			return "StateMachineBuilder.exe"
		end,
	}
)
```

If your mesh asset type is set up differently (for example your built meshes keep their extension), that doesn't matter: this block doesn't depend on it.

### 5. Add a state machine file to your game

Copy `Examples\guard.fsm` (or write your own) to `MyGame_\Content\StateMachines\guard.fsm`, and add a `stateMachines` list to `MyGame_\Content\AssetsToBuild.lua`:

```lua
return
{
	shaders = { ... },
	meshes = { ... },
	stateMachines =
	{
		"StateMachines/guard.fsm",
	},
}
```

The built file ends up at `data/statemachines/guard.fsmbin` in your game's install folder (the asset build system writes lower-case paths), and that is the path you load at run time.

### 6. Build

Build the solution. In the Output window you should see a line like

```text
Built C:\...\MyGame_\Content\statemachines/guard.fsm
```

If the `.fsm` file has a mistake, the build fails with an error that has the file and line number; double-click it to jump there.

No changes to shared code (Graphics, Application, the Assignment 01 code, ...) are needed.

## The .fsm file format

A `.fsm` file is a Lua file that returns one table. Here is the guard example, shortened:

```lua
return
{
	initialState = "Patrol",

	parameters =
	{
		{ name = "distanceToPlayer", type = "float", default = 1000.0 },
		{ name = "canSeePlayer", type = "bool", default = false },
		{ name = "health", type = "float", default = 100.0 },
		{ name = "wasHit", type = "trigger" },
	},

	-- Checked from every state, before the state's own transitions
	anyState =
	{
		{ to = "Flee", conditions = { { "health", "<", 20.0 } } },
	},

	states =
	{
		{
			name = "Patrol",
			transitions =
			{
				{ to = "Chase", conditions = { { "canSeePlayer", "==", true } } },
				{ to = "Chase", conditions = { { "wasHit" } } },
			},
		},
		{
			name = "Chase",
			transitions =
			{
				{ to = "Attack", conditions = { { "distanceToPlayer", "<", 1.1 } } },
				{ to = "Patrol", conditions = { { "canSeePlayer", "==", false } }, minimumTimeInState = 2.0 },
			},
		},
		{ name = "Attack", transitions = { { to = "Chase", conditions = { { "distanceToPlayer", ">", 1.4 } } } } },
		-- A state doesn't need any transitions of its own
		{ name = "Flee" },
	},
}
```

### Top-level fields

| Field | Required | Meaning |
| --- | --- | --- |
| `initialState` | yes | Name of the state that every new state machine starts in. |
| `parameters` | no | The values your game sets. Can be left out if you only use timed transitions. |
| `anyState` | no | Transitions that are checked from every state (e.g. "flee when health is low"). |
| `states` | yes | At least one state. |

### Parameters

`{ name = "...", type = "float" | "bool" | "trigger", default = ... }`

- **float**: any number. `default` is optional (0).
- **bool**: `true` / `false`. `default` is optional (false).
- **trigger**: a one-shot event, like "was hit" or "lock key pressed". You set it with `SetTrigger()`, it stays set during the next `Update()`, and the state machine resets it at the end of that `Update()` whether a transition used it or not. A trigger has no `default`.

Names must be unique. They are only used to look up handles (see below), so use whatever names you like.

### States and transitions

`{ name = "...", transitions = { <transition>, ... } }`

A transition is `{ to = "<state name>", conditions = { <condition>, ... }, minimumTimeInState = <seconds> }`:

- `to` is required and must be the name of a state.
- `conditions` is optional. **All** conditions must be true for the transition to fire. A transition without conditions fires as soon as `minimumTimeInState` has passed (this is how the door's Opening state turns into Open after one second).
- `minimumTimeInState` is optional (0). The transition can't fire until the state machine has been in its current state for at least this many seconds. It is measured from when the current state was entered, not from when the conditions became true.

  So `{ to = "Patrol", conditions = { { "canSeePlayer", "==", false } }, minimumTimeInState = 3.0 }` means "at least 3 s in Chase, and right now the player isn't visible", not "the player hasn't been visible for 3 s". If you need the second meaning, keep the timer in your game and pass it in as a float:

  ```lua
  { name = "timeSinceSawPlayer", type = "float" },
  ...
  { to = "Patrol", conditions = { { "timeSinceSawPlayer", ">", 3.0 } } },
  ```

  ```cpp
  m_timeSinceSawPlayer = canSeePlayer ? 0.0f : ( m_timeSinceSawPlayer + i_elapsedSecondCount_sinceLastUpdate );
  m_guard.ai.SetFloat( m_guardParameters.timeSinceSawPlayer, m_timeSinceSawPlayer );
  ```

Transitions are checked in this order, and the **first** one that is true fires:

1. the `anyState` transitions, in the order they are written (one that leads to the state you are already in is skipped, so "Flee when health < 20" doesn't restart Flee every update);
2. the current state's own transitions, in the order they are written.

At most one transition fires per `Update()`.

### Conditions

| Form | Example | Meaning |
| --- | --- | --- |
| `{ floatName, op, number }` | `{ "distanceToPlayer", "<", 1.1 }` | `op` is one of `<` `<=` `>` `>=` `==` `~=` |
| `{ boolName, op, true/false }` | `{ "canSeePlayer", "==", false }` | only `==` and `~=` (not equal, as in Lua) |
| `{ boolName }` | `{ "isPlayerNear" }` | short for `== true` |
| `{ triggerName }` | `{ "wasHit" }` | true if the trigger was set since the last update |

### Errors the builder reports

The builder checks everything once at build time, so the run time never has to. Each error names the file and, when it can, the line. These are the ones you are most likely to see:

- The file has a Lua syntax error (with Lua's own message and line number).
- The file doesn't return a table.
- `initialState` is missing, or it names a state that doesn't exist.
- There is no `states` array, or it is empty.
- Two states or two parameters have the same name.
- A parameter has no `name`, or its `type` isn't `"float"`, `"bool"` or `"trigger"`.
- A default value has the wrong type (a string for a float, a number for a bool), or a trigger has a default.
- A transition has no `to`, or `to` names a state that doesn't exist.
- `minimumTimeInState` isn't a number or is negative.
- A condition uses a parameter that doesn't exist.
- A condition isn't `{ name, op, value }` or `{ name }`.
- A float is used without a comparison (`{ "health" }`), or a trigger is compared with a value (`{ "wasHit", "==", true }`).
- The operator isn't one of `<` `<=` `>` `>=` `==` `~=`, or a bool is compared with `<` etc.
- The value has the wrong type for the parameter (`{ "health", "<", "low" }`).
- More than 65534 states, parameters, transitions or conditions (you won't hit this).

At run time `cStateMachineDefinition::Load()` also checks that the built file isn't damaged and was written by the same version of the builder; if you ever see "has version N, but this version of the engine can only load version M", rebuild your assets.

## Using it in your game

The two classes are in the `eae6320::AI` namespace:

- `cStateMachineDefinition`: what you load from a file. Read-only and reference counted (like `cMesh` and `cEffect`), so any number of agents can share one.
- `cStateMachine`: one per agent. Holds the agent's current state, how long it has been there, and its parameter values.

The snippets below are taken from the demo game; `m_guard` is a struct with a `cGameObject object` and a `cStateMachine ai`.

### 1. Include the headers and declare members

```cpp
// cMyGame.h
#include <Engine/StateMachine/cStateMachine.h>

// in the class:
AI::cStateMachineDefinition* m_stateMachine_guard = nullptr;   // shared definition
struct sGuard
{
	cGameObject object;
	AI::cStateMachine ai;                                       // one per guard
} m_guard;
struct
{
	AI::sParameterHandle distanceToPlayer;
	AI::sParameterHandle canSeePlayer;
	AI::sParameterHandle wasHit;
} m_guardParameters;
```

(`cStateMachine.h` includes `cStateMachineDefinition.h`.)

### 2. Load the definition and look up handles (in Initialize())

```cpp
if ( !( result = AI::cStateMachineDefinition::Load( "data/statemachines/guard.fsmbin", m_stateMachine_guard ) ) )
{
	EAE6320_ASSERTF( false, "Can't initialize MyGame without the guard's state machine" );
	return result;
}

// Names are looked up once; after that the game only uses the handles
const auto patrolState = m_stateMachine_guard->GetStateHandle( "Patrol" );
const auto chaseState = m_stateMachine_guard->GetStateHandle( "Chase" );
m_guardParameters.distanceToPlayer = m_stateMachine_guard->GetParameterHandle( "distanceToPlayer" );
m_guardParameters.canSeePlayer = m_stateMachine_guard->GetParameterHandle( "canSeePlayer" );
m_guardParameters.wasHit = m_stateMachine_guard->GetParameterHandle( "wasHit" );
if ( !patrolState.IsValid() || !chaseState.IsValid() || !m_guardParameters.distanceToPlayer.IsValid() /* ... */ )
{
	// A misspelled name gives an invalid handle (and an assert + log message)
	return Results::Failure;
}
```

### 3. Create one cStateMachine per agent and register callbacks

```cpp
if ( !( result = m_guard.ai.Initialize( *m_stateMachine_guard, "Guard" ) ) )   // "Guard" is only for the debug output
{
	return result;
}
// { onEnter, onUpdate, onExit }; any of them can be nullptr.
// The last argument is passed to the callbacks as i_userData.
m_guard.ai.SetCallbacks( patrolState, { OnEnterPatrol, OnUpdatePatrol, nullptr }, this );
m_guard.ai.SetCallbacks( chaseState, { OnEnterChase, OnUpdateChase, nullptr }, this );
```

Callbacks are plain functions (or static member functions, so that they can see your class's private members):

```cpp
// fStateCallback (enter and exit)
static void OnEnterChase( AI::cStateMachine& io_stateMachine, void* i_userData );
// fStateUpdateCallback
static void OnUpdateChase( AI::cStateMachine& io_stateMachine, void* i_userData, const float i_elapsedSecondCount );

void eae6320::cMyGame::OnEnterChase( AI::cStateMachine&, void* i_userData )
{
	auto& game = *static_cast<cMyGame*>( i_userData );
	game.m_guard.object.SetMesh( game.m_mesh_cone );
	game.m_guard.object.SetEffect( game.m_effect_guardChase );
}
```

The user data can be anything. The guard passes the game (`this`); the door passes the door itself (`&m_door`), which means the same callbacks work for any number of doors:

```cpp
m_door.ai.SetCallbacks( openingState, { OnEnterDoorMoving, OnUpdateDoorOpening, OnExitDoorMoving }, &m_door );

void eae6320::cMyGame::OnExitDoorMoving( AI::cStateMachine&, void* i_userData )
{
	auto& door = *static_cast<sDoor*>( i_userData );
	door.object.SetVelocity( Math::sVector() );
}
```

Several agents can share one definition: give each its own `cStateMachine`, `Initialize()` it with the same definition and its own debug name ("Guard 1", "Guard 2"), and pass its own user data.

### 4. Every simulation update: set parameters, then Update()

Do this in `UpdateSimulationBasedOnTime()` (not in `UpdateBasedOnInput()`), so the AI runs at the fixed simulation rate:

```cpp
const auto distanceToPlayer = ( m_player.GetPosition() - m_guard.object.GetPosition() ).GetLength();
m_guard.ai.SetFloat( m_guardParameters.distanceToPlayer, distanceToPlayer );
m_guard.ai.SetBool( m_guardParameters.canSeePlayer, distanceToPlayer < s_guardSightRadius );
if ( m_wasGuardHit )
{
	m_wasGuardHit = false;
	m_guard.ai.SetTrigger( m_guardParameters.wasHit );
}
m_guard.ai.Update( i_elapsedSecondCount_sinceLastUpdate );
```

Using a parameter with the wrong setter (e.g. `SetFloat()` on a bool) asserts in Debug builds and is ignored in Release builds.

What `Update()` does, in order:

1. The first time only: calls the initial state's `onEnter` (it is not called in `Initialize()`, so callbacks you register after `Initialize()` still get it).
2. Adds the elapsed time to the time in the current state.
3. Finds the first transition that is true (see the order above). If there is one: calls the old state's `onExit`, changes state, resets the time in state, writes the debug line, calls the new state's `onEnter`.
4. Calls the current state's `onUpdate` with the elapsed time (also right after a state change).
5. Resets all triggers.

Inside a callback you may set parameters, but don't call `Update()`.

### 5. Ask about the state

You can react in callbacks only, ask the state machine, or both:

```cpp
if ( m_guard.ai.GetCurrentState() == attackState ) { /* ... */ }
const float secondsInState = m_guard.ai.GetTimeInCurrentState();
const char* const name = m_stateMachine_guard->GetStateName( m_guard.ai.GetCurrentState() );   // for UI or logs
```

Store the handles you compare against (e.g. as members); don't call `GetStateHandle()` every frame, because it compares strings.

### 6. Clean up (in CleanUp())

```cpp
m_guard.ai.CleanUp();   // releases its reference to the definition (the destructor does this too)
if ( m_stateMachine_guard )
{
	m_stateMachine_guard->DecrementReferenceCount();   // the reference that Load() gave you
	m_stateMachine_guard = nullptr;
}
```

## Debug output

In Debug builds every state change writes one line to Visual Studio's Output window and to the game's log (`eae6320.log` next to the exe):

```text
Guard: Patrol -> Chase (transition: canSeePlayer == true)
Guard: Chase -> Attack (transition: distanceToPlayer < 1.1)
Guard: Attack -> Chase (transition: distanceToPlayer > 1.4)
Guard: Chase -> Patrol (transition: canSeePlayer == false and 2 s in state)
Guard: Patrol -> Flee (transition: any state, health < 20)
Door: Closed -> Locked (transition: toggleLock is set)
```

How to read it: `<debug name>: <old state> -> <new state> (transition: <the conditions that were true>)`. The conditions are written the way they are in the `.fsm` file, so you can search the file for them. `any state,` means an `anyState` transition fired, `N s in state` is the `minimumTimeInState`, and `always` means a transition without conditions or minimum time.

Turning it on or off: it is controlled by `EAE6320_AI_SHOULDOUTPUTSTATECHANGES` in `Engine/StateMachine/Configuration.h`, which is defined in Debug builds. Define it unconditionally if you want the lines in Release builds too.

Sending the lines somewhere else: call `DebugOutput::SetOutputFunction()` once, e.g. in your game's `Initialize()`. Your function gets the state machine that changed and the finished line. Passing `nullptr` goes back to the default. The function can be set in every configuration (no `#ifdef` needed); it is only called when the debug output is enabled.

```cpp
#include <Engine/StateMachine/DebugOutput.h>

namespace
{
	void OutputStateChange( const eae6320::AI::cStateMachine& i_stateMachine, const char* const i_line, void* i_userData )
	{
		// e.g. show it in your own on-screen console, filter by agent, count state changes...
		auto& game = *static_cast<eae6320::cMyGame*>( i_userData );
		game.AddConsoleLine( i_line );
		// keep the default output as well:
		eae6320::AI::DebugOutput::OutputToDebuggerAndLog( i_stateMachine, i_line, nullptr );
	}
}

// in Initialize():
AI::DebugOutput::SetOutputFunction( OutputStateChange, this );
```

The output function is global (one for all state machines) and must be set from the thread that updates the state machines.

If you want to print a whole definition (e.g. to check what was loaded), `cStateMachineDefinition` has getters for every state, parameter and transition, and `DescribeConditions( transitionIndex )` returns a transition's conditions as text in the same words as above.

## Known limits

- Flat state machines only: no nested (hierarchical) states and no "sub-machines".
- At most one transition per `Update()`. If a chain of transitions should happen (A -> B -> C), it takes one update per step.
- Conditions are only ANDed. For "A or B", write two transitions to the same state (the guard does this: `canSeePlayer` or `wasHit` both lead to Chase).
- Triggers last exactly one `Update()`. If you set a trigger in a state that doesn't check it, it is lost (the door ignores the lock key while it is open on purpose).
- Parameters are global to the machine. There are no per-state variables; keep those in your own agent struct.
- `==` on floats is an exact comparison; use `<`/`>` for floats.
- `GetStateHandle()` / `GetParameterHandle()` are case-sensitive string compares: call them once at load time.
- The debug output function is shared by all state machines and isn't thread-safe.
- Definitions can't be reloaded while the game is running; rebuild and restart.

## Troubleshooting

| What you see | Cause |
| --- | --- |
| Asset build error: `The builder "...StateMachineBuilder.exe" doesn't exist` | Step 3.2: BuildMyGameAssets doesn't depend on StateMachineBuilder yet. |
| Asset build error: no asset type `stateMachines` / the file isn't built | Step 4: the `NewAssetTypeInfo( "stateMachines", ... )` block is missing or the list name in `AssetsToBuild.lua` isn't exactly `stateMachines`. |
| Linker error `unresolved external symbol ... cStateMachine ...` | Step 3.1: your game doesn't reference the StateMachine project. |
| `Cannot open include file: 'Engine/StateMachine/...'` | The folder isn't at `<solution>\Engine\StateMachine`. |
| At startup: `Failed to load the state machine file data/statemachines/...` | Wrong path (built paths are lower-case and end in `.fsmbin`), or the file isn't in `AssetsToBuild.lua`. |
| Assert `The state machine doesn't have a state named "..."` | A name in your C++ doesn't match the `.fsm` file (case matters). |
| Assert `The parameter "..." is used with the wrong type` | e.g. `SetBool()` on a float parameter. |
| Nothing happens, no state changes | You never call `Update()`, or you set the parameters after `Update()`, or (for triggers) the current state has no transition that checks it. |
