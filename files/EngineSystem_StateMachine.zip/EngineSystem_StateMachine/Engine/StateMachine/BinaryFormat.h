/*
	This file describes the layout of a built (binary) state machine file.

	StateMachineBuilder writes these structs and cStateMachineDefinition reads them,
	and so both include this file to make sure that they always agree.
	Game code normally doesn't need to include this file directly.

	A built file contains (in this order):
		1. sHeader
		2. sParameter[parameterCount]
		3. sState[stateCount]
		4. sTransition[transitionCount]
		5. sCondition[conditionCount]
		6. The name block: nameBlockSize bytes of null-terminated strings

	Every struct has a size that is a multiple of 4 bytes,
	and so every array starts 4-byte aligned if the file data itself is
	(the memory returned by Platform::LoadBinaryFile() is).
	The name block only contains chars and so it doesn't need any alignment.

	Indices in the file are used directly as handles at run time:
		* A state handle is an index into the state array
		* A parameter handle is an index into the parameter array
*/

#ifndef EAE6320_AI_BINARYFORMAT_H
#define EAE6320_AI_BINARYFORMAT_H

// Includes
//=========

#include <cstdint>

// Type Definitions
//=================

namespace eae6320
{
	namespace AI
	{
		// The kinds of values that a state machine parameter can hold
		enum class eParameterType : uint8_t
		{
			Float,
			Bool,
			// A trigger is a bool that the run-time state machine resets to false after each update
			// (it is used for one-shot events like "the agent was hit")
			Trigger,
		};

		// The comparisons that a transition condition can make
		// between a parameter's current value and the condition's constant
		enum class eComparison : uint8_t
		{
			Less,			// <
			LessOrEqual,	// <=
			Greater,		// >
			GreaterOrEqual,	// >=
			Equal,			// ==
			NotEqual,		// ~=
			// Only for triggers: the condition is true if the trigger has been set since the last update
			IsSet,
		};

		namespace BinaryFormat
		{
			// The value written in sHeader::fileVersion;
			// it is changed whenever the layout of the file changes
			// so that an old built file is reported instead of being misread
			constexpr uint16_t currentFileVersion = 1;
			// The value used in the file for "no index"
			constexpr uint16_t invalidIndex = 0xffff;

			// 16 bytes
			struct sHeader
			{
				uint16_t fileVersion;
				uint16_t parameterCount;
				uint16_t stateCount;
				uint16_t transitionCount;
				uint16_t conditionCount;
				// The state that every new state machine instance starts in
				uint16_t initialState;
				// The "any state" transitions are stored at the start of the transition array:
				// transitions [0, anyStateTransitionCount) are checked from every state
				// (before the current state's own transitions)
				uint16_t anyStateTransitionCount;
				// The size of the name block in bytes
				// (names are found by their offset in the block, which is a uint16_t,
				// and so the block can't be bigger than this anyway)
				uint16_t nameBlockSize;
			};

			// 8 bytes
			struct sParameter
			{
				// Bools and triggers store 0.0f (false) or 1.0f (true)
				float defaultValue;
				// The byte offset of the name in the name block
				uint16_t nameOffset;
				eParameterType type;
				uint8_t padding;
			};

			// 8 bytes
			struct sState
			{
				// The state's own transitions are [firstTransition, firstTransition + transitionCount)
				// in the transition array
				uint16_t firstTransition;
				uint16_t transitionCount;
				// The byte offset of the name in the name block
				uint16_t nameOffset;
				uint16_t padding;
			};

			// 12 bytes
			struct sTransition
			{
				// The transition can't fire until the state machine has been in its current state at least this long
				// (0 means that there is no minimum)
				float minimumTimeInState;
				uint16_t targetState;
				// The transition's conditions are [firstCondition, firstCondition + conditionCount)
				// in the condition array, and they all have to be true for the transition to fire
				// (a transition with no conditions fires as soon as the minimum time has passed)
				uint16_t firstCondition;
				uint16_t conditionCount;
				uint16_t padding;
			};

			// 8 bytes
			struct sCondition
			{
				// The constant that the parameter is compared with
				// (bools store 0.0f or 1.0f; IsSet doesn't use it)
				float value;
				uint16_t parameter;
				eComparison comparison;
				uint8_t padding;
			};

			static_assert( sizeof( sHeader ) == 16, "The size of sHeader must match the built files" );
			static_assert( sizeof( sParameter ) == 8, "The size of sParameter must match the built files" );
			static_assert( sizeof( sState ) == 8, "The size of sState must match the built files" );
			static_assert( sizeof( sTransition ) == 12, "The size of sTransition must match the built files" );
			static_assert( sizeof( sCondition ) == 8, "The size of sCondition must match the built files" );
		}
	}
}

#endif	// EAE6320_AI_BINARYFORMAT_H
