/*
	This file provides configurable settings
	that can be used to control the state machine library
*/

#ifndef EAE6320_AI_CONFIGURATION_H
#define EAE6320_AI_CONFIGURATION_H

// By default every state change is written to the debugger's output window and the log
// only in debug builds,
// but you can #define it differently as necessary
// (e.g. to see the state changes of a release build).
// Where the lines go can be changed at run time with DebugOutput::SetOutputFunction() (see DebugOutput.h).
#ifdef _DEBUG
	#define EAE6320_AI_SHOULDOUTPUTSTATECHANGES
#endif

#endif	// EAE6320_AI_CONFIGURATION_H
