// Includes
//=========

#include "cStateMachineDefinition.h"

#include <cstdio>
#include <cstring>
#include <new>
#include <string>
#include <utility>
#include <Engine/Asserts/Asserts.h>
#include <Engine/Logging/Logging.h>
#include <Engine/ScopeGuard/cScopeGuard.h>

// Helper Declarations
//====================

namespace
{
	// Checks that every index and name offset in the file refers to something that exists,
	// so that the run time never has to check them again
	eae6320::cResult ValidateIndices( const char* const i_path, const eae6320::AI::BinaryFormat::sHeader& i_header,
		const eae6320::AI::BinaryFormat::sParameter* const i_parameters, const eae6320::AI::BinaryFormat::sState* const i_states,
		const eae6320::AI::BinaryFormat::sTransition* const i_transitions, const eae6320::AI::BinaryFormat::sCondition* const i_conditions,
		const char* const i_names );
}

// Interface
//==========

// Initialize / Clean Up
//----------------------

eae6320::cResult eae6320::AI::cStateMachineDefinition::Load( const char* const i_path, cStateMachineDefinition*& o_definition )
{
	auto result = Results::Success;
	EAE6320_ASSERT( o_definition == nullptr );

	// Load the entire built file as a single chunk of memory
	Platform::sDataFromFile dataFromFile;
	{
		std::string errorMessage;
		if ( !( result = Platform::LoadBinaryFile( i_path, dataFromFile, &errorMessage ) ) )
		{
			EAE6320_ASSERTF( false, errorMessage.c_str() );
			Logging::OutputError( "Failed to load the state machine file %s: %s", i_path, errorMessage.c_str() );
			o_definition = nullptr;
			return result;
		}
	}

	cStateMachineDefinition* newDefinition = nullptr;
	cScopeGuard scopeGuard( [&o_definition, &result, &newDefinition]
		{
			if ( result )
			{
				EAE6320_ASSERT( newDefinition != nullptr );
				o_definition = newDefinition;
			}
			else
			{
				if ( newDefinition )
				{
					newDefinition->DecrementReferenceCount();
					newDefinition = nullptr;
				}
				o_definition = nullptr;
			}
		} );

	// Allocate a new definition
	newDefinition = new ( std::nothrow ) cStateMachineDefinition();
	if ( !newDefinition )
	{
		result = Results::OutOfMemory;
		EAE6320_ASSERTF( false, "Couldn't allocate memory for a state machine definition" );
		Logging::OutputError( "Failed to allocate memory for the state machine definition %s", i_path );
		return result;
	}
	// Unlike a mesh (which copies its data to the GPU) the definition keeps using the file's memory,
	// and so the loaded data is moved into it instead of being freed at the end of this function
	if ( !( result = newDefinition->Initialize( i_path, std::move( dataFromFile ) ) ) )
	{
		EAE6320_ASSERTF( false, "The state machine file %s is invalid", i_path );
		return result;
	}

	return result;
}

// Name Lookups
//-------------

eae6320::AI::sStateHandle eae6320::AI::cStateMachineDefinition::GetStateHandle( const char* const i_name ) const
{
	if ( i_name )
	{
		for ( uint16_t i = 0; i < m_header->stateCount; ++i )
		{
			if ( std::strcmp( m_names + m_states[i].nameOffset, i_name ) == 0 )
			{
				return sStateHandle{ i };
			}
		}
	}
	EAE6320_ASSERTF( false, "The state machine doesn't have a state named \"%s\"", i_name ? i_name : "" );
	Logging::OutputError( "The state machine doesn't have a state named \"%s\"", i_name ? i_name : "" );
	return sStateHandle{};
}

eae6320::AI::sParameterHandle eae6320::AI::cStateMachineDefinition::GetParameterHandle( const char* const i_name ) const
{
	if ( i_name )
	{
		for ( uint16_t i = 0; i < m_header->parameterCount; ++i )
		{
			if ( std::strcmp( m_names + m_parameters[i].nameOffset, i_name ) == 0 )
			{
				return sParameterHandle{ i };
			}
		}
	}
	EAE6320_ASSERTF( false, "The state machine doesn't have a parameter named \"%s\"", i_name ? i_name : "" );
	Logging::OutputError( "The state machine doesn't have a parameter named \"%s\"", i_name ? i_name : "" );
	return sParameterHandle{};
}

// States
//-------

uint16_t eae6320::AI::cStateMachineDefinition::GetStateCount() const
{
	return m_header->stateCount;
}

eae6320::AI::sStateHandle eae6320::AI::cStateMachineDefinition::GetInitialState() const
{
	return sStateHandle{ m_header->initialState };
}

const char* eae6320::AI::cStateMachineDefinition::GetStateName( const sStateHandle i_state ) const
{
	return ( i_state.index < m_header->stateCount ) ? ( m_names + m_states[i_state.index].nameOffset ) : "";
}

uint16_t eae6320::AI::cStateMachineDefinition::GetTransitionCount( const sStateHandle i_state ) const
{
	return ( i_state.index < m_header->stateCount ) ? m_states[i_state.index].transitionCount : 0;
}

const eae6320::AI::BinaryFormat::sState& eae6320::AI::cStateMachineDefinition::GetState( const sStateHandle i_state ) const
{
	EAE6320_ASSERT( i_state.index < m_header->stateCount );
	return m_states[i_state.index];
}

// Parameters
//-----------

uint16_t eae6320::AI::cStateMachineDefinition::GetParameterCount() const
{
	return m_header->parameterCount;
}

const char* eae6320::AI::cStateMachineDefinition::GetParameterName( const sParameterHandle i_parameter ) const
{
	return ( i_parameter.index < m_header->parameterCount ) ? ( m_names + m_parameters[i_parameter.index].nameOffset ) : "";
}

eae6320::AI::eParameterType eae6320::AI::cStateMachineDefinition::GetParameterType( const sParameterHandle i_parameter ) const
{
	EAE6320_ASSERT( i_parameter.index < m_header->parameterCount );
	return m_parameters[i_parameter.index].type;
}

float eae6320::AI::cStateMachineDefinition::GetParameterDefaultValue( const sParameterHandle i_parameter ) const
{
	EAE6320_ASSERT( i_parameter.index < m_header->parameterCount );
	return m_parameters[i_parameter.index].defaultValue;
}

// Transitions
//------------

uint16_t eae6320::AI::cStateMachineDefinition::GetTransitionCount() const
{
	return m_header->transitionCount;
}

uint16_t eae6320::AI::cStateMachineDefinition::GetConditionCount() const
{
	return m_header->conditionCount;
}

uint16_t eae6320::AI::cStateMachineDefinition::GetAnyStateTransitionCount() const
{
	return m_header->anyStateTransitionCount;
}

std::string eae6320::AI::cStateMachineDefinition::DescribeConditions( const uint16_t i_transitionIndex ) const
{
	EAE6320_ASSERT( i_transitionIndex < m_header->transitionCount );
	if ( i_transitionIndex >= m_header->transitionCount )
	{
		return "(invalid transition)";
	}
	const auto& transition = m_transitions[i_transitionIndex];

	// The same operators as in the .fsm file, in the order of eComparison
	constexpr const char* const comparisonNames[] = { "<", "<=", ">", ">=", "==", "~=", "is set" };
	std::string description;
	const auto append = [&description]( const char* const i_text )
	{
		if ( !description.empty() )
		{
			description += " and ";
		}
		description += i_text;
	};
	for ( uint16_t i = 0; i < transition.conditionCount; ++i )
	{
		const auto& condition = m_conditions[transition.firstCondition + i];
		const sParameterHandle parameter{ condition.parameter };
		const auto* const parameterName = GetParameterName( parameter );
		char text[128];
		if ( condition.comparison == eComparison::IsSet )
		{
			snprintf( text, sizeof( text ), "%s is set", parameterName );
		}
		else if ( GetParameterType( parameter ) == eParameterType::Bool )
		{
			snprintf( text, sizeof( text ), "%s %s %s", parameterName,
				comparisonNames[static_cast<size_t>( condition.comparison )], ( condition.value != 0.0f ) ? "true" : "false" );
		}
		else
		{
			snprintf( text, sizeof( text ), "%s %s %g", parameterName,
				comparisonNames[static_cast<size_t>( condition.comparison )], static_cast<double>( condition.value ) );
		}
		append( text );
	}
	if ( transition.minimumTimeInState > 0.0f )
	{
		char text[64];
		snprintf( text, sizeof( text ), "%g s in state", static_cast<double>( transition.minimumTimeInState ) );
		append( text );
	}
	return description.empty() ? std::string( "always" ) : description;
}

// Implementation
//===============

// Initialize / Clean Up
//----------------------

eae6320::cResult eae6320::AI::cStateMachineDefinition::Initialize( const char* const i_path, Platform::sDataFromFile&& io_fileData )
{
	m_fileData = std::move( io_fileData );

	// The file contains (in this order):
	//	1. The header (with the counts)
	//	2. The parameter array
	//	3. The state array
	//	4. The transition array
	//	5. The condition array
	//	6. The name block
	// Each array is used directly from the loaded file:
	// the pointers are found by adding the size of everything before them,
	// without copying or looping over the elements
	auto currentOffset = reinterpret_cast<uintptr_t>( m_fileData.data );
	const auto finalOffset = currentOffset + m_fileData.size;

	if ( ( currentOffset + sizeof( BinaryFormat::sHeader ) ) > finalOffset )
	{
		Logging::OutputError( "The state machine file %s is too small to contain a header", i_path );
		return Results::InvalidFile;
	}
	m_header = reinterpret_cast<const BinaryFormat::sHeader*>( currentOffset );
	currentOffset += sizeof( BinaryFormat::sHeader );
	if ( m_header->fileVersion != BinaryFormat::currentFileVersion )
	{
		Logging::OutputError( "The state machine file %s has version %u, but this version of the engine can only load version %u"
			" (build the assets again)", i_path, m_header->fileVersion, BinaryFormat::currentFileVersion );
		return Results::InvalidFile;
	}

	const auto parameterArraySize = sizeof( BinaryFormat::sParameter ) * m_header->parameterCount;
	const auto stateArraySize = sizeof( BinaryFormat::sState ) * m_header->stateCount;
	const auto transitionArraySize = sizeof( BinaryFormat::sTransition ) * m_header->transitionCount;
	const auto conditionArraySize = sizeof( BinaryFormat::sCondition ) * m_header->conditionCount;
	if ( ( currentOffset + parameterArraySize + stateArraySize + transitionArraySize + conditionArraySize + m_header->nameBlockSize )
		!= finalOffset )
	{
		Logging::OutputError( "The state machine file %s is %zu bytes, which doesn't match the counts in its header", i_path, m_fileData.size );
		return Results::InvalidFile;
	}

	m_parameters = reinterpret_cast<const BinaryFormat::sParameter*>( currentOffset );
	currentOffset += parameterArraySize;
	m_states = reinterpret_cast<const BinaryFormat::sState*>( currentOffset );
	currentOffset += stateArraySize;
	m_transitions = reinterpret_cast<const BinaryFormat::sTransition*>( currentOffset );
	currentOffset += transitionArraySize;
	m_conditions = reinterpret_cast<const BinaryFormat::sCondition*>( currentOffset );
	currentOffset += conditionArraySize;
	m_names = reinterpret_cast<const char*>( currentOffset );

	return ValidateIndices( i_path, *m_header, m_parameters, m_states, m_transitions, m_conditions, m_names );
}

eae6320::AI::cStateMachineDefinition::~cStateMachineDefinition()
{
	EAE6320_ASSERT( m_referenceCount == 0 );
	// The arrays point into the file data, which is freed here
	m_header = nullptr;
	m_parameters = nullptr;
	m_states = nullptr;
	m_transitions = nullptr;
	m_conditions = nullptr;
	m_names = nullptr;
	m_fileData.Free();
}

// Helper Definitions
//===================

namespace
{
	eae6320::cResult ValidateIndices( const char* const i_path, const eae6320::AI::BinaryFormat::sHeader& i_header,
		const eae6320::AI::BinaryFormat::sParameter* const i_parameters, const eae6320::AI::BinaryFormat::sState* const i_states,
		const eae6320::AI::BinaryFormat::sTransition* const i_transitions, const eae6320::AI::BinaryFormat::sCondition* const i_conditions,
		const char* const i_names )
	{
		// StateMachineBuilder has already checked everything in the human-readable file,
		// and so these checks only fail if the built file is damaged or was written by a different version of the builder.
		// They are done once at load time so that the run time can trust every index.
		const auto onError = [i_path]( const char* const i_problem )
		{
			EAE6320_ASSERTF( false, "The state machine file %s is invalid: %s", i_path, i_problem );
			eae6320::Logging::OutputError( "The state machine file %s is invalid: %s", i_path, i_problem );
			return eae6320::Results::InvalidFile;
		};

		if ( ( i_header.stateCount == 0 ) || ( i_header.initialState >= i_header.stateCount ) )
		{
			return onError( "the initial state doesn't exist" );
		}
		if ( i_header.anyStateTransitionCount > i_header.transitionCount )
		{
			return onError( "there are more \"any state\" transitions than transitions" );
		}
		// Every name must end inside the name block
		if ( ( i_header.nameBlockSize == 0 ) || ( i_names[i_header.nameBlockSize - 1] != '\0' ) )
		{
			return onError( "the name block isn't null-terminated" );
		}
		for ( uint16_t i = 0; i < i_header.parameterCount; ++i )
		{
			if ( ( i_parameters[i].nameOffset >= i_header.nameBlockSize ) || ( i_parameters[i].type > eae6320::AI::eParameterType::Trigger ) )
			{
				return onError( "a parameter has an invalid name or type" );
			}
		}
		for ( uint16_t i = 0; i < i_header.stateCount; ++i )
		{
			const auto& state = i_states[i];
			if ( ( state.nameOffset >= i_header.nameBlockSize )
				|| ( ( static_cast<uint32_t>( state.firstTransition ) + state.transitionCount ) > i_header.transitionCount ) )
			{
				return onError( "a state has an invalid name or transition range" );
			}
		}
		for ( uint16_t i = 0; i < i_header.transitionCount; ++i )
		{
			const auto& transition = i_transitions[i];
			if ( ( transition.targetState >= i_header.stateCount )
				|| ( ( static_cast<uint32_t>( transition.firstCondition ) + transition.conditionCount ) > i_header.conditionCount ) )
			{
				return onError( "a transition has an invalid target state or condition range" );
			}
		}
		for ( uint16_t i = 0; i < i_header.conditionCount; ++i )
		{
			const auto& condition = i_conditions[i];
			if ( ( condition.parameter >= i_header.parameterCount ) || ( condition.comparison > eae6320::AI::eComparison::IsSet ) )
			{
				return onError( "a condition has an invalid parameter or comparison" );
			}
		}

		return eae6320::Results::Success;
	}
}
