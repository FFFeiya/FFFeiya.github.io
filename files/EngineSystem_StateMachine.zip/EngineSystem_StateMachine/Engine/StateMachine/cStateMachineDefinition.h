/*
	A state machine definition is the shared, read-only part of a state machine:
	which states exist, which parameters the game can set,
	and which transitions (with which conditions) connect the states.

	It is loaded from a binary file that StateMachineBuilder built
	from a human-readable .fsm file in the game's Content/StateMachines folder.
	One definition can be shared by any number of agents
	(each agent will own its own small cStateMachine instance that refers to the definition),
	and so it is reference counted like cMesh and cEffect.

	Names are only needed to look up handles once (e.g. during initialization);
	after that everything works with the small integer handles.

	Usage:
		eae6320::AI::cStateMachineDefinition* guardDefinition = nullptr;
		if ( eae6320::AI::cStateMachineDefinition::Load( "data/StateMachines/guard.fsmbin", guardDefinition ) )
		{
			const auto chaseState = guardDefinition->GetStateHandle( "Chase" );
			const auto distanceParameter = guardDefinition->GetParameterHandle( "distanceToPlayer" );
			...
			guardDefinition->DecrementReferenceCount();
			guardDefinition = nullptr;
		}
*/

#ifndef EAE6320_AI_CSTATEMACHINEDEFINITION_H
#define EAE6320_AI_CSTATEMACHINEDEFINITION_H

// Includes
//=========

#include "BinaryFormat.h"

#include <cstdint>
#include <string>
#include <Engine/Assets/ReferenceCountedAssets.h>
#include <Engine/Platform/Platform.h>
#include <Engine/Results/Results.h>

// Type Definitions
//=================

namespace eae6320
{
	namespace AI
	{
		// A handle refers to one state of a specific definition.
		// It is only meaningful together with the definition that returned it.
		struct sStateHandle
		{
			uint16_t index = BinaryFormat::invalidIndex;

			bool IsValid() const { return index != BinaryFormat::invalidIndex; }
			bool operator ==( const sStateHandle i_other ) const { return index == i_other.index; }
			bool operator !=( const sStateHandle i_other ) const { return index != i_other.index; }
		};

		// A handle refers to one parameter of a specific definition.
		// It is only meaningful together with the definition that returned it.
		struct sParameterHandle
		{
			uint16_t index = BinaryFormat::invalidIndex;

			bool IsValid() const { return index != BinaryFormat::invalidIndex; }
			bool operator ==( const sParameterHandle i_other ) const { return index == i_other.index; }
			bool operator !=( const sParameterHandle i_other ) const { return index != i_other.index; }
		};
	}
}

// Class Declaration
//==================

namespace eae6320
{
	namespace AI
	{
		class cStateMachineDefinition
		{
			// Interface
			//==========

		public:

			// Initialize / Clean Up
			//----------------------

			// Loads a definition from a binary file built by StateMachineBuilder.
			// On success o_definition holds one reference that the caller must release with DecrementReferenceCount().
			// If the file can't be loaded (or isn't a valid state machine file) an error is logged,
			// a failure is returned, and o_definition is set to nullptr.
			static cResult Load( const char* const i_path, cStateMachineDefinition*& o_definition );

			EAE6320_ASSETS_DECLAREDELETEDREFERENCECOUNTEDFUNCTIONS( cStateMachineDefinition );

			// Reference Counting
			//-------------------

			EAE6320_ASSETS_DECLAREREFERENCECOUNTINGFUNCTIONS();

			// Name Lookups
			//-------------

			// These compare strings, and so they should be called once (e.g. during initialization)
			// and the handles should be stored instead of calling them every frame.
			// If no state or parameter has the given name an invalid handle is returned
			// (and an error is logged, because it is almost always a typo).
			sStateHandle GetStateHandle( const char* const i_name ) const;
			sParameterHandle GetParameterHandle( const char* const i_name ) const;

			// States
			//-------

			uint16_t GetStateCount() const;
			sStateHandle GetInitialState() const;
			// Returns an empty string for an invalid handle
			const char* GetStateName( const sStateHandle i_state ) const;
			// The number of transitions that belong to the given state
			// (not counting the "any state" transitions, which are checked from every state)
			uint16_t GetTransitionCount( const sStateHandle i_state ) const;

			// Parameters
			//-----------

			uint16_t GetParameterCount() const;
			// Returns an empty string for an invalid handle
			const char* GetParameterName( const sParameterHandle i_parameter ) const;
			eParameterType GetParameterType( const sParameterHandle i_parameter ) const;
			// Bools and triggers return 0.0f (false) or 1.0f (true)
			float GetParameterDefaultValue( const sParameterHandle i_parameter ) const;

			// Transitions
			//------------

			// The total number of transitions and conditions in the definition
			uint16_t GetTransitionCount() const;
			uint16_t GetConditionCount() const;
			uint16_t GetAnyStateTransitionCount() const;
			// Describes a transition's conditions in the same words as the .fsm file,
			// e.g. "canSeePlayer == false and 2 s in state" (or "always" if it has no conditions).
			// i_transitionIndex is an index into the whole transition array (see GetTransitions()).
			// This is meant for logs and debug displays; the debug output uses it for every state change.
			std::string DescribeConditions( const uint16_t i_transitionIndex ) const;

			// Raw Data
			//---------

			// The run-time state machine (cStateMachine) evaluates transitions directly from these arrays.
			// Game code only needs them to list a definition's contents
			// (the "any state" transitions are [0, GetAnyStateTransitionCount()) in GetTransitions(),
			// and a state's own transitions are described by its sState)
			const BinaryFormat::sState& GetState( const sStateHandle i_state ) const;
			const BinaryFormat::sTransition* GetTransitions() const { return m_transitions; }
			const BinaryFormat::sCondition* GetConditions() const { return m_conditions; }

			// Data
			//=====

		private:

			// The whole built file is kept in one block of memory,
			// and the pointers below point into it
			Platform::sDataFromFile m_fileData;
			const BinaryFormat::sHeader* m_header = nullptr;
			const BinaryFormat::sParameter* m_parameters = nullptr;
			const BinaryFormat::sState* m_states = nullptr;
			const BinaryFormat::sTransition* m_transitions = nullptr;
			const BinaryFormat::sCondition* m_conditions = nullptr;
			const char* m_names = nullptr;
			EAE6320_ASSETS_DECLAREREFERENCECOUNT();

			// Implementation
			//===============

		private:

			// Points the array pointers into the loaded file and checks that the file is consistent
			cResult Initialize( const char* const i_path, Platform::sDataFromFile&& io_fileData );

			cStateMachineDefinition() = default;
			~cStateMachineDefinition();
		};
	}
}

#endif	// EAE6320_AI_CSTATEMACHINEDEFINITION_H
