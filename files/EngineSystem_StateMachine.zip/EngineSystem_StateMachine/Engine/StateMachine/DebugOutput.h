/*
	The debug output of the state machine library

	Whenever a transition fires, cStateMachine::Update() writes one line in the form
		"<debug name>: <old state> -> <new state> (transition: <conditions>)"
	e.g.
		"Guard: Chase -> Patrol (transition: canSeePlayer == false and 2 s in state)"

	By default the line is written to the debugger's output window and to the log.
	A game can send it somewhere else instead (e.g. to an on-screen console)
	by calling SetOutputFunction() once during initialization.

	State changes are only output if EAE6320_AI_SHOULDOUTPUTSTATECHANGES is defined
	(in Debug builds by default, see Configuration.h).
	The functions in this file can always be called, though,
	so that game code doesn't need any #ifdefs.
*/

#ifndef EAE6320_AI_DEBUGOUTPUT_H
#define EAE6320_AI_DEBUGOUTPUT_H

// Includes
//=========

#include "Configuration.h"

#include <cstdint>

// Forward Declarations
//=====================

namespace eae6320
{
	namespace AI
	{
		class cStateMachine;
		struct sStateHandle;
	}
}

// Interface
//==========

namespace eae6320
{
	namespace AI
	{
		namespace DebugOutput
		{
			// Receives one line for every state change.
			// i_stateMachine is the machine that changed state (it is already in the new state),
			// and i_userData is the pointer that was passed to SetOutputFunction().
			using fOutputFunction = void (*)( const cStateMachine& i_stateMachine, const char* const i_line, void* i_userData );

			// Replaces the function that state changes are written with (for every state machine).
			// Passing nullptr goes back to the default (OutputToDebuggerAndLog()).
			// It should be called from the same thread that updates the state machines
			// (e.g. in the game's Initialize()).
			void SetOutputFunction( const fOutputFunction i_outputFunction, void* const i_userData = nullptr );

			// The default output function: writes the line to the debugger's output window and to the log.
			// A custom output function can call it too if it wants to keep the default output.
			void OutputToDebuggerAndLog( const cStateMachine& i_stateMachine, const char* const i_line, void* i_userData );

			// Writes one line of text to the debugger's output window (a newline is added).
			// This is the only platform-specific part of the library (Windows/DebugOutput.win.cpp).
			void OutputToDebugger( const char* const i_line );

#ifdef EAE6320_AI_SHOULDOUTPUTSTATECHANGES
			// cStateMachine::Update() calls this after it has changed state; game code doesn't need to.
			// i_transitionIndex is the index of the transition that fired in the definition's transition array.
			void OutputStateChange( const cStateMachine& i_stateMachine, const sStateHandle i_oldState, const uint16_t i_transitionIndex );
#endif
		}
	}
}

#endif	// EAE6320_AI_DEBUGOUTPUT_H
