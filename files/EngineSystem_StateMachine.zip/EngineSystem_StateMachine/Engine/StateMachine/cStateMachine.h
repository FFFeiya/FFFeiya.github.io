/*
	A state machine is the per-agent, run-time part of a state machine:
	which state the agent is in, how long it has been there,
	and the current values of the definition's parameters.

	Every agent owns its own cStateMachine,
	and any number of them can share one cStateMachineDefinition
	(each instance holds a reference to its definition while it is initialized).

	How it is used:
		1. Initialize() it with a definition (parameters start with the defaults from the .fsm file)
		2. Optionally register enter / update / exit callbacks for the states the game cares about
		3. Every simulation update, set the parameters (SetFloat() / SetBool() / SetTrigger())
			and then call Update() once
		4. Either react in the callbacks or ask GetCurrentState()

	Example:
		eae6320::AI::cStateMachine guardAi;
		if ( guardAi.Initialize( *guardDefinition, "Guard" ) )
		{
			guardAi.SetCallbacks( chaseState, { OnEnterChase, OnUpdateChase, nullptr }, &guard );
		}
		...
		// Every simulation update:
		guardAi.SetFloat( distanceParameter, distance );
		guardAi.SetBool( canSeeParameter, distance < sightRadius );
		guardAi.Update( i_elapsedSecondCount_sinceLastUpdate );
		...
		guardAi.CleanUp();

	What Update() does, in this order:
		1. The first time it is called the initial state's enter callback is called
			(and not in Initialize(), so that callbacks registered after Initialize() still see it)
		2. The time in the current state is increased by the elapsed time
		3. The "any state" transitions are checked, then the current state's own transitions,
			each list in the order of the .fsm file.
			The first transition whose conditions are all true (and whose minimumTimeInState has passed) fires,
			and at most one transition fires per Update().
			An "any state" transition to the state that the machine is already in is skipped
			(it would otherwise exit and re-enter the state every update for as long as its conditions are true).
		4. If a transition fired: the old state's exit callback is called,
			the current state changes, the time in state is reset to zero,
			and the new state's enter callback is called
		5. The (possibly new) current state's update callback is called with the elapsed time
		6. All triggers are reset to false

	In builds with the debug output enabled (Debug builds by default, see Configuration.h)
	every state change is written to the debugger's output window and the log as
		"<debug name>: <old state> -> <new state> (transition: <conditions>)"
	(the line is written after the old state's exit callback and before the new state's enter callback).
	A game can send these lines somewhere else with DebugOutput::SetOutputFunction() (see DebugOutput.h).
*/

#ifndef EAE6320_AI_CSTATEMACHINE_H
#define EAE6320_AI_CSTATEMACHINE_H

// Includes
//=========

#include "cStateMachineDefinition.h"

#include <cstdint>
#include <string>
#include <vector>
#include <Engine/Results/Results.h>

// Class Declaration
//==================

namespace eae6320
{
	namespace AI
	{
		class cStateMachine
		{
			// Type Definitions
			//=================

		public:

			// Called when a state is entered or exited.
			// io_stateMachine is the machine that changed state,
			// and i_userData is the pointer that was passed to SetCallbacks() (e.g. the agent's game object).
			// (A callback may set parameters, but it must not call Update().)
			using fStateCallback = void (*)( cStateMachine& io_stateMachine, void* i_userData );
			// Called once per Update() for the current state, with the same elapsed time that Update() received
			using fStateUpdateCallback = void (*)( cStateMachine& io_stateMachine, void* i_userData, const float i_elapsedSecondCount );

			// Any of the three can be nullptr
			struct sCallbacks
			{
				fStateCallback onEnter = nullptr;
				fStateUpdateCallback onUpdate = nullptr;
				fStateCallback onExit = nullptr;
			};

			// Interface
			//==========

		public:

			// Initialize / Clean Up
			//----------------------

			// Takes a reference on the definition (released in CleanUp()),
			// sets every parameter to its default value, and starts in the definition's initial state.
			// The debug name is only used for the debug output (e.g. "Guard 2"); it is copied.
			cResult Initialize( cStateMachineDefinition& i_definition, const char* const i_debugName );
			// Releases the reference on the definition and forgets all callbacks.
			// It is safe to call this more than once (and the destructor calls it).
			void CleanUp();

			cStateMachine() = default;
			~cStateMachine();
			// A state machine is owned by exactly one agent
			cStateMachine( const cStateMachine& ) = delete;
			cStateMachine& operator =( const cStateMachine& ) = delete;

			// Callbacks
			//----------

			// Registers the callbacks for one state, replacing any that were registered before.
			// i_userData is passed unchanged to every one of the three callbacks.
			void SetCallbacks( const sStateHandle i_state, const sCallbacks& i_callbacks, void* const i_userData );

			// Parameters
			//-----------

			// Each setter asserts (in Debug builds) that the parameter has the matching type
			// in the definition; in Release builds a mismatched call is ignored.
			void SetFloat( const sParameterHandle i_parameter, const float i_value );
			void SetBool( const sParameterHandle i_parameter, const bool i_value );
			// A trigger stays set until the end of the next Update()
			void SetTrigger( const sParameterHandle i_parameter );

			float GetFloat( const sParameterHandle i_parameter ) const;
			bool GetBool( const sParameterHandle i_parameter ) const;
			bool IsTriggerSet( const sParameterHandle i_parameter ) const;

			// Update
			//-------

			// Checks the transitions, changes state if one fires, and calls the callbacks
			// (see the top of this file for the exact order).
			// It should be called once per simulation update after the parameters have been set.
			void Update( const float i_elapsedSecondCount );

			// State
			//------

			sStateHandle GetCurrentState() const { return m_currentState; }
			// The seconds that have passed in Update() calls since the current state was entered
			float GetTimeInCurrentState() const { return m_timeInCurrentState; }
			// nullptr if the state machine isn't initialized
			const cStateMachineDefinition* GetDefinition() const { return m_definition; }
			const char* GetDebugName() const { return m_debugName.c_str(); }

			// Data
			//=====

		private:

			struct sStateCallbacks
			{
				sCallbacks callbacks;
				void* userData = nullptr;
			};

			cStateMachineDefinition* m_definition = nullptr;
			// One value per parameter of the definition (bools and triggers are 0.0f or 1.0f)
			std::vector<float> m_parameterValues;
			// One entry per state of the definition
			std::vector<sStateCallbacks> m_callbacks;
			std::string m_debugName;
			sStateHandle m_currentState;
			float m_timeInCurrentState = 0.0f;
			// The initial state's enter callback is called in the first Update()
			bool m_hasEnteredInitialState = false;

			// Implementation
			//===============

		private:

			bool IsParameterOfType( const sParameterHandle i_parameter, const eParameterType i_type ) const;
			bool AreConditionsTrue( const BinaryFormat::sTransition& i_transition ) const;
			// Returns the index (in the definition's transition array) of the transition that should fire,
			// or BinaryFormat::invalidIndex if none should
			uint16_t FindTransitionToFire() const;
			void CallEnter();
			void CallExit();
		};
	}
}

#endif	// EAE6320_AI_CSTATEMACHINE_H
