/*
	This file lists external prebuilt libraries that this library depends on
*/

#pragma once

// External Libraries
//===================

// OutputDebugStringA()
#pragma comment( lib, "Kernel32.lib" )
