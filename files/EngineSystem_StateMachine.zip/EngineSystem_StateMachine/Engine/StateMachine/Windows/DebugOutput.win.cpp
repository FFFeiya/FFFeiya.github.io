// Includes
//=========

#include "../DebugOutput.h"

#include <Engine/Windows/Includes.h>

// Interface
//==========

void eae6320::AI::DebugOutput::OutputToDebugger( const char* const i_line )
{
	// OutputDebugStringA() shows the text in Visual Studio's Output window
	// (and in tools like DebugView when no debugger is attached)
	OutputDebugStringA( i_line );
	OutputDebugStringA( "\n" );
}
