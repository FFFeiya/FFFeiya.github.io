// Includes
//=========

#include "cStateMachine.h"

#include "DebugOutput.h"

#include <Engine/Asserts/Asserts.h>

// Interface
//==========

// Initialize / Clean Up
//----------------------

eae6320::cResult eae6320::AI::cStateMachine::Initialize( cStateMachineDefinition& i_definition, const char* const i_debugName )
{
	// Initializing twice would otherwise leak the reference on the first definition
	CleanUp();

	m_definition = &i_definition;
	m_definition->IncrementReferenceCount();
	m_debugName = i_debugName ? i_debugName : "";

	// Every parameter starts with the default value from the .fsm file
	const auto parameterCount = m_definition->GetParameterCount();
	m_parameterValues.resize( parameterCount );
	for ( uint16_t i = 0; i < parameterCount; ++i )
	{
		m_parameterValues[i] = m_definition->GetParameterDefaultValue( sParameterHandle{ i } );
	}
	m_callbacks.resize( m_definition->GetStateCount() );

	m_currentState = m_definition->GetInitialState();
	m_timeInCurrentState = 0.0f;
	m_hasEnteredInitialState = false;

	return Results::Success;
}

void eae6320::AI::cStateMachine::CleanUp()
{
	if ( m_definition )
	{
		m_definition->DecrementReferenceCount();
		m_definition = nullptr;
	}
	m_parameterValues.clear();
	m_callbacks.clear();
	m_currentState = sStateHandle{};
	m_timeInCurrentState = 0.0f;
	m_hasEnteredInitialState = false;
}

eae6320::AI::cStateMachine::~cStateMachine()
{
	CleanUp();
}

// Callbacks
//----------

void eae6320::AI::cStateMachine::SetCallbacks( const sStateHandle i_state, const sCallbacks& i_callbacks, void* const i_userData )
{
	EAE6320_ASSERTF( m_definition, "The state machine must be initialized before callbacks are set" );
	EAE6320_ASSERTF( i_state.IsValid() && ( i_state.index < m_callbacks.size() ), "Invalid state handle" );
	if ( i_state.IsValid() && ( i_state.index < m_callbacks.size() ) )
	{
		m_callbacks[i_state.index] = { i_callbacks, i_userData };
	}
}

// Parameters
//-----------

void eae6320::AI::cStateMachine::SetFloat( const sParameterHandle i_parameter, const float i_value )
{
	if ( IsParameterOfType( i_parameter, eParameterType::Float ) )
	{
		m_parameterValues[i_parameter.index] = i_value;
	}
}

void eae6320::AI::cStateMachine::SetBool( const sParameterHandle i_parameter, const bool i_value )
{
	if ( IsParameterOfType( i_parameter, eParameterType::Bool ) )
	{
		m_parameterValues[i_parameter.index] = i_value ? 1.0f : 0.0f;
	}
}

void eae6320::AI::cStateMachine::SetTrigger( const sParameterHandle i_parameter )
{
	if ( IsParameterOfType( i_parameter, eParameterType::Trigger ) )
	{
		m_parameterValues[i_parameter.index] = 1.0f;
	}
}

float eae6320::AI::cStateMachine::GetFloat( const sParameterHandle i_parameter ) const
{
	return IsParameterOfType( i_parameter, eParameterType::Float ) ? m_parameterValues[i_parameter.index] : 0.0f;
}

bool eae6320::AI::cStateMachine::GetBool( const sParameterHandle i_parameter ) const
{
	return IsParameterOfType( i_parameter, eParameterType::Bool ) ? ( m_parameterValues[i_parameter.index] != 0.0f ) : false;
}

bool eae6320::AI::cStateMachine::IsTriggerSet( const sParameterHandle i_parameter ) const
{
	return IsParameterOfType( i_parameter, eParameterType::Trigger ) ? ( m_parameterValues[i_parameter.index] != 0.0f ) : false;
}

// Update
//-------

void eae6320::AI::cStateMachine::Update( const float i_elapsedSecondCount )
{
	EAE6320_ASSERTF( m_definition, "The state machine must be initialized before it is updated" );
	if ( !m_definition )
	{
		return;
	}

	// The initial state is entered in the first update
	// (so that callbacks that were registered after Initialize() still get the enter call)
	if ( !m_hasEnteredInitialState )
	{
		m_hasEnteredInitialState = true;
		CallEnter();
	}

	m_timeInCurrentState += i_elapsedSecondCount;

	// At most one transition fires per update
	{
		const auto transitionIndex = FindTransitionToFire();
		if ( transitionIndex != BinaryFormat::invalidIndex )
		{
			const auto oldState = m_currentState;
			CallExit();
			m_currentState = sStateHandle{ m_definition->GetTransitions()[transitionIndex].targetState };
			m_timeInCurrentState = 0.0f;
#ifdef EAE6320_AI_SHOULDOUTPUTSTATECHANGES
			// The line is written before the new state's enter callback,
			// so that anything the callback logs comes after it
			DebugOutput::OutputStateChange( *this, oldState, transitionIndex );
#endif
			CallEnter();
		}
	}

	// The current state is updated every time, including right after it was entered
	{
		const auto& stateCallbacks = m_callbacks[m_currentState.index];
		if ( stateCallbacks.callbacks.onUpdate )
		{
			stateCallbacks.callbacks.onUpdate( *this, stateCallbacks.userData, i_elapsedSecondCount );
		}
	}

	// Triggers only last for one update
	for ( uint16_t i = 0; i < m_definition->GetParameterCount(); ++i )
	{
		if ( m_definition->GetParameterType( sParameterHandle{ i } ) == eParameterType::Trigger )
		{
			m_parameterValues[i] = 0.0f;
		}
	}
}

// Implementation
//===============

bool eae6320::AI::cStateMachine::IsParameterOfType( const sParameterHandle i_parameter, const eParameterType i_type ) const
{
	EAE6320_ASSERTF( m_definition, "The state machine must be initialized before its parameters are used" );
	if ( !m_definition || !i_parameter.IsValid() || ( i_parameter.index >= m_parameterValues.size() ) )
	{
		EAE6320_ASSERTF( false, "Invalid parameter handle" );
		return false;
	}
	const auto type = m_definition->GetParameterType( i_parameter );
	EAE6320_ASSERTF( type == i_type, "The parameter \"%s\" is used with the wrong type", m_definition->GetParameterName( i_parameter ) );
	return type == i_type;
}

bool eae6320::AI::cStateMachine::AreConditionsTrue( const BinaryFormat::sTransition& i_transition ) const
{
	if ( m_timeInCurrentState < i_transition.minimumTimeInState )
	{
		return false;
	}
	const auto* const conditions = m_definition->GetConditions();
	for ( uint16_t i = 0; i < i_transition.conditionCount; ++i )
	{
		const auto& condition = conditions[i_transition.firstCondition + i];
		// Bools and triggers are stored as 0.0f or 1.0f,
		// and so every comparison can be made on floats
		const auto value = m_parameterValues[condition.parameter];
		bool isTrue = false;
		switch ( condition.comparison )
		{
		case eComparison::Less: isTrue = value < condition.value; break;
		case eComparison::LessOrEqual: isTrue = value <= condition.value; break;
		case eComparison::Greater: isTrue = value > condition.value; break;
		case eComparison::GreaterOrEqual: isTrue = value >= condition.value; break;
		case eComparison::Equal: isTrue = value == condition.value; break;
		case eComparison::NotEqual: isTrue = value != condition.value; break;
		case eComparison::IsSet: isTrue = value != 0.0f; break;
		}
		if ( !isTrue )
		{
			return false;
		}
	}
	return true;
}

uint16_t eae6320::AI::cStateMachine::FindTransitionToFire() const
{
	const auto* const transitions = m_definition->GetTransitions();

	// The "any state" transitions are checked first.
	// One that leads to the current state is skipped,
	// because otherwise it would exit and re-enter the state on every update
	// for as long as its conditions stay true
	// (e.g. "Flee when health < 20" while already fleeing)
	for ( uint16_t i = 0; i < m_definition->GetAnyStateTransitionCount(); ++i )
	{
		const auto& transition = transitions[i];
		if ( ( transition.targetState != m_currentState.index ) && AreConditionsTrue( transition ) )
		{
			return i;
		}
	}
	// Then the current state's own transitions, in the order of the .fsm file
	{
		const auto& state = m_definition->GetState( m_currentState );
		for ( uint16_t i = 0; i < state.transitionCount; ++i )
		{
			const auto transitionIndex = static_cast<uint16_t>( state.firstTransition + i );
			if ( AreConditionsTrue( transitions[transitionIndex] ) )
			{
				return transitionIndex;
			}
		}
	}
	return BinaryFormat::invalidIndex;
}

void eae6320::AI::cStateMachine::CallEnter()
{
	const auto& stateCallbacks = m_callbacks[m_currentState.index];
	if ( stateCallbacks.callbacks.onEnter )
	{
		stateCallbacks.callbacks.onEnter( *this, stateCallbacks.userData );
	}
}

void eae6320::AI::cStateMachine::CallExit()
{
	const auto& stateCallbacks = m_callbacks[m_currentState.index];
	if ( stateCallbacks.callbacks.onExit )
	{
		stateCallbacks.callbacks.onExit( *this, stateCallbacks.userData );
	}
}
