// Includes
//=========

#include "DebugOutput.h"

#include "cStateMachine.h"

#include <cstdio>
#include <string>
#include <Engine/Logging/Logging.h>

// Static Data
//============

namespace
{
	eae6320::AI::DebugOutput::fOutputFunction s_outputFunction = eae6320::AI::DebugOutput::OutputToDebuggerAndLog;
	void* s_outputUserData = nullptr;
}

// Interface
//==========

void eae6320::AI::DebugOutput::SetOutputFunction( const fOutputFunction i_outputFunction, void* const i_userData )
{
	s_outputFunction = i_outputFunction ? i_outputFunction : OutputToDebuggerAndLog;
	s_outputUserData = i_userData;
}

void eae6320::AI::DebugOutput::OutputToDebuggerAndLog( const cStateMachine&, const char* const i_line, void* )
{
	OutputToDebugger( i_line );
	Logging::OutputMessage( "%s", i_line );
}

#ifdef EAE6320_AI_SHOULDOUTPUTSTATECHANGES

void eae6320::AI::DebugOutput::OutputStateChange( const cStateMachine& i_stateMachine, const sStateHandle i_oldState, const uint16_t i_transitionIndex )
{
	const auto* const definition = i_stateMachine.GetDefinition();
	if ( !definition )
	{
		return;
	}
	std::string conditions = definition->DescribeConditions( i_transitionIndex );
	if ( i_transitionIndex < definition->GetAnyStateTransitionCount() )
	{
		conditions = "any state, " + conditions;
	}

	char line[512];
	snprintf( line, sizeof( line ), "%s: %s -> %s (transition: %s)", i_stateMachine.GetDebugName(),
		definition->GetStateName( i_oldState ), definition->GetStateName( i_stateMachine.GetCurrentState() ), conditions.c_str() );
	s_outputFunction( i_stateMachine, line, s_outputUserData );
}

#endif	// EAE6320_AI_SHOULDOUTPUTSTATECHANGES
