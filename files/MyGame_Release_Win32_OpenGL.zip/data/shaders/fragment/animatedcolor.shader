	#version 420
layout( std140, binding = 0 ) uniform g_constantBuffer_frame
{
	mat4 g_transform_worldToCamera;
	mat4 g_transform_cameraToProjected;
	float g_elapsedSecondCount_systemTime;
	float g_elapsedSecondCount_simulationTime;
	vec2 g_padding;
};
out vec4 o_color;
void main()
{
	o_color = vec4( 1.0, 1.0, 1.0, 1.0 );
	{
		o_color.r = ( sin( g_elapsedSecondCount_simulationTime ) * 0.5 ) + 0.5;
		o_color.g = ( sin( ( g_elapsedSecondCount_simulationTime * 1.7 ) + 2.0 ) * 0.5 ) + 0.5;
		o_color.b = ( cos( g_elapsedSecondCount_simulationTime * 0.8 ) * 0.5 ) + 0.5;
	}
}
